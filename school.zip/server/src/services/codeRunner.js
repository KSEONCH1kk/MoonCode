import { spawn, exec } from 'child_process'
import { writeFileSync, mkdirSync, rmSync, existsSync } from 'fs'
import { join } from 'path'
import { v4 as uuid } from 'uuid'
import { fileURLToPath } from 'url'
import { dirname } from 'path'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

// Temp directory for code execution
const TEMP_DIR = join(__dirname, '../../temp')
if (!existsSync(TEMP_DIR)) {
  mkdirSync(TEMP_DIR, { recursive: true })
}

// Language configurations
const LANGUAGES = {
  java: {
    extension: '.java',
    compile: (dir, filename) => `javac "${join(dir, filename)}"`,
    run: (dir, classname) => `java -cp "${dir}" ${classname}`,
    getClassName: (code) => {
      const match = code.match(/public\s+class\s+(\w+)/)
      return match ? match[1] : 'Main'
    },
    timeout: 10000,
  },
  python: {
    extension: '.py',
    compile: null,
    run: (dir, filename) => `python "${join(dir, filename)}"`,
    timeout: 10000,
  },
  javascript: {
    extension: '.js',
    compile: null,
    run: (dir, filename) => `node "${join(dir, filename)}"`,
    timeout: 10000,
  },
  typescript: {
    extension: '.ts',
    compile: (dir, filename) => `npx tsc "${join(dir, filename)}" --outDir "${dir}"`,
    run: (dir, filename) => `node "${join(dir, filename.replace('.ts', '.js'))}"`,
    timeout: 15000,
  },
  cpp: {
    extension: '.cpp',
    compile: (dir, filename) => `g++ "${join(dir, filename)}" -o "${join(dir, 'program.exe')}"`,
    run: (dir) => `"${join(dir, 'program.exe')}"`,
    timeout: 10000,
  },
  c: {
    extension: '.c',
    compile: (dir, filename) => `gcc "${join(dir, filename)}" -o "${join(dir, 'program.exe')}"`,
    run: (dir) => `"${join(dir, 'program.exe')}"`,
    timeout: 10000,
  },
  go: {
    extension: '.go',
    compile: null,
    run: (dir, filename) => `go run "${join(dir, filename)}"`,
    timeout: 10000,
  },
  rust: {
    extension: '.rs',
    compile: (dir, filename) => `rustc "${join(dir, filename)}" -o "${join(dir, 'program.exe')}"`,
    run: (dir) => `"${join(dir, 'program.exe')}"`,
    timeout: 15000,
  },
  kotlin: {
    extension: '.kt',
    compile: (dir, filename) => `kotlinc "${join(dir, filename)}" -include-runtime -d "${join(dir, 'program.jar')}"`,
    run: (dir) => `java -jar "${join(dir, 'program.jar')}"`,
    timeout: 30000,
  },
  csharp: {
    extension: '.cs',
    compile: (dir, filename) => `csc "${join(dir, filename)}" -out:"${join(dir, 'program.exe')}"`,
    run: (dir) => `"${join(dir, 'program.exe')}"`,
    timeout: 15000,
  },
  php: {
    extension: '.php',
    compile: null,
    run: (dir, filename) => `php "${join(dir, filename)}"`,
    timeout: 10000,
  },
  ruby: {
    extension: '.rb',
    compile: null,
    run: (dir, filename) => `ruby "${join(dir, filename)}"`,
    timeout: 10000,
  },
}

// Execute command with timeout
function executeCommand(command, timeout = 10000, input = '') {
  return new Promise((resolve) => {
    const startTime = Date.now()
    
    const child = exec(command, {
      timeout,
      maxBuffer: 1024 * 1024,
      encoding: 'utf8',
    }, (error, stdout, stderr) => {
      const executionTime = Date.now() - startTime
      
      if (error) {
        if (error.killed) {
          resolve({
            success: false,
            output: stdout,
            error: `Time Limit Exceeded (${timeout}ms)`,
            executionTime,
            timedOut: true,
          })
        } else {
          resolve({
            success: false,
            output: stdout,
            error: stderr || error.message,
            executionTime,
          })
        }
      } else {
        resolve({
          success: true,
          output: stdout,
          error: stderr,
          executionTime,
        })
      }
    })

    if (input && child.stdin) {
      child.stdin.write(input)
      child.stdin.end()
    }
  })
}

// Execute with stdin input
function executeWithInput(command, input, timeout) {
  return new Promise((resolve) => {
    const startTime = Date.now()
    
    const child = exec(command, {
      timeout,
      maxBuffer: 1024 * 1024,
      encoding: 'utf8',
    }, (error, stdout, stderr) => {
      const executionTime = Date.now() - startTime
      
      if (error) {
        if (error.killed) {
          resolve({
            success: false,
            output: stdout,
            error: `Time Limit Exceeded (${timeout}ms)`,
            executionTime,
            timedOut: true,
          })
        } else {
          resolve({
            success: false,
            output: stdout,
            error: stderr || error.message,
            executionTime,
          })
        }
      } else {
        resolve({
          success: true,
          output: stdout,
          error: stderr,
          executionTime,
        })
      }
    })

    if (input && child.stdin) {
      child.stdin.write(input)
      child.stdin.end()
    }
  })
}

// Normalize output for comparison
function normalizeOutput(output) {
  return output
    .trim()
    .replace(/\r\n/g, '\n')
    .replace(/\s+$/gm, '')
    .replace(/^\s+/gm, '')
}

// Wrap Java code with main method if needed for test execution
function wrapJavaCodeForTest(code, testInput) {
  // Check if code has a main method
  if (code.includes('public static void main')) {
    return code
  }
  
  // Extract class name
  const classMatch = code.match(/public\s+class\s+(\w+)/)
  const className = classMatch ? classMatch[1] : 'Solution'
  
  // Find all public static methods to create test calls
  const methodMatch = code.match(/public\s+static\s+(\w+)\s+(\w+)\s*\(([^)]*)\)/)
  
  if (!methodMatch) {
    // No static method found, just add empty main
    return code.replace(
      /}\s*$/,
      `\n    public static void main(String[] args) {\n        // No method to test\n    }\n}`
    )
  }
  
  const returnType = methodMatch[1]
  const methodName = methodMatch[2]
  const params = methodMatch[3]
  
  // Parse input and generate call
  let mainMethod
  if (params.includes('int a') && params.includes('int b')) {
    // Two int parameters - read from stdin
    mainMethod = `
    public static void main(String[] args) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.println(${methodName}(a, b));
    }`
  } else if (params.includes('int n')) {
    // Single int parameter
    mainMethod = `
    public static void main(String[] args) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        int n = sc.nextInt();
        System.out.println(${methodName}(n));
    }`
  } else if (params.includes('String')) {
    // String parameter
    mainMethod = `
    public static void main(String[] args) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        String s = sc.nextLine();
        System.out.println(${methodName}(s));
    }`
  } else if (params.trim() === '') {
    // No parameters
    mainMethod = `
    public static void main(String[] args) {
        ${returnType === 'void' ? methodName + '();' : 'System.out.println(' + methodName + '());'}
    }`
  } else {
    // Generic fallback
    mainMethod = `
    public static void main(String[] args) {
        // Auto-generated main
        System.out.println("Test runner ready");
    }`
  }
  
  // Insert main method before closing brace
  return code.replace(/}\s*$/, mainMethod + '\n}')
}

// Execute code
export async function executeCode(code, language, input = '', testCases = []) {
  const langConfig = LANGUAGES[language]
  if (!langConfig) {
    return { success: false, error: `Unsupported language: ${language}`, stage: 'system' }
  }

  const sessionId = uuid()
  const sessionDir = join(TEMP_DIR, sessionId)
  
  try {
    mkdirSync(sessionDir, { recursive: true })

    // For Java, wrap code with main method if needed for tests
    let processedCode = code
    if (language === 'java' && testCases.length > 0) {
      processedCode = wrapJavaCodeForTest(code, testCases[0]?.input || '')
    }

    // Determine filename
    let filename
    if (language === 'java') {
      const className = langConfig.getClassName(processedCode)
      filename = `${className}${langConfig.extension}`
    } else {
      filename = `main${langConfig.extension}`
    }

    // Write code to file
    const filepath = join(sessionDir, filename)
    writeFileSync(filepath, processedCode, 'utf8')

    // Compile if needed
    if (langConfig.compile) {
      const compileCmd = langConfig.compile(sessionDir, filename)
      const compileResult = await executeCommand(compileCmd, langConfig.timeout)
      
      if (!compileResult.success) {
        return {
          success: false,
          stage: 'compile',
          output: '',
          error: compileResult.error,
          executionTime: compileResult.executionTime,
        }
      }
    }

    // Run tests if provided
    if (testCases.length > 0) {
      const results = []
      
      for (const testCase of testCases) {
        const runCmd = language === 'java' 
          ? langConfig.run(sessionDir, langConfig.getClassName(code))
          : langConfig.run(sessionDir, filename)
        
        const result = await executeWithInput(runCmd, testCase.input, langConfig.timeout)
        
        const passed = result.success && 
          normalizeOutput(result.output) === normalizeOutput(testCase.expected)
        
        results.push({
          input: testCase.input,
          expected: testCase.expected,
          actual: result.output.trim(),
          passed,
          error: result.error,
          executionTime: result.executionTime,
        })
      }

      const allPassed = results.every(r => r.passed)
      const totalExecutionTime = results.reduce((sum, r) => sum + (r.executionTime || 0), 0)
      
      return {
        success: allPassed,
        stage: 'test',
        testResults: results,
        passedCount: results.filter(r => r.passed).length,
        totalCount: results.length,
        executionTime: totalExecutionTime,
      }
    }

    // Simple run without test cases
    const runCmd = language === 'java'
      ? langConfig.run(sessionDir, langConfig.getClassName(code))
      : langConfig.run(sessionDir, filename)
    
    const runResult = await executeWithInput(runCmd, input, langConfig.timeout)

    return {
      success: runResult.success,
      stage: 'run',
      output: runResult.output,
      error: runResult.error,
      executionTime: runResult.executionTime,
      timedOut: runResult.timedOut || false,
    }

  } catch (error) {
    return { 
      success: false, 
      error: error.message,
      stage: 'system',
    }
  } finally {
    // Cleanup
    try {
      rmSync(sessionDir, { recursive: true, force: true })
    } catch (e) {
      // Ignore cleanup errors
    }
  }
}

export default { executeCode, LANGUAGES }

