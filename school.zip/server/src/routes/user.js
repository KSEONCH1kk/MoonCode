import { Router } from 'express'
import { v4 as uuid } from 'uuid'
import db from '../db/database.js'
import { authenticate } from '../middleware/auth.js'
import { validateTitle, validateContent, validateUUID, sanitizeText } from '../utils/sanitize.js'

const router = Router()

// Get user enrollments with course details and dynamic progress
router.get('/enrollments', authenticate, (req, res) => {
  try {
    const enrollments = db.prepare(`
      SELECT e.*, 
        c.title as course_title, c.slug as course_slug, c.image as course_image,
        c.description as course_description, c.level as course_level,
        c.duration_hours as course_duration, c.category as course_category,
        u.name as teacher_name
      FROM enrollments e
      JOIN courses c ON e.course_id = c.id
      LEFT JOIN users u ON c.teacher_id = u.id
      WHERE e.user_id = ?
      ORDER BY e.enrolled_at DESC
    `).all(req.user.id)

    // Calculate dynamic progress for each enrollment
    const result = enrollments.map(e => {
      // Count total lessons in course
      const totalLessons = db.prepare(`
        SELECT COUNT(*) as count 
        FROM lessons l
        JOIN modules m ON l.module_id = m.id
        WHERE m.course_id = ?
      `).get(e.course_id).count

      // Count completed lessons for this user in this course
      const completedLessons = db.prepare(`
        SELECT COUNT(*) as count 
        FROM lesson_progress lp
        JOIN lessons l ON lp.lesson_id = l.id
        JOIN modules m ON l.module_id = m.id
        WHERE lp.user_id = ? AND m.course_id = ? AND lp.status = 'completed'
      `).get(req.user.id, e.course_id).count

      // Calculate progress percentage
      const progress = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0

      return {
        id: e.id,
        user_id: e.user_id,
        course_id: e.course_id,
        enrolled_at: e.enrolled_at,
        completed_at: e.completed_at,
        progress,
        completedLessons,
        totalLessons,
        status: e.status,
        course: {
          id: e.course_id,
          title: e.course_title,
          slug: e.course_slug,
          image: e.course_image,
          description: e.course_description,
          level: e.course_level,
          duration_hours: e.course_duration,
          category: e.course_category,
          teacher_name: e.teacher_name
        }
      }
    })

    res.json(result)
  } catch (error) {
    console.error('Get enrollments error:', error)
    res.status(500).json({ error: 'Ошибка получения записей' })
  }
})

// Get user statistics
router.get('/stats', authenticate, (req, res) => {
  try {
    // Total lessons completed
    const lessonsCompleted = db.prepare(`
      SELECT COUNT(*) as count FROM lesson_progress 
      WHERE user_id = ? AND status = 'completed'
    `).get(req.user.id).count

    // Total courses completed
    const coursesCompleted = db.prepare(`
      SELECT COUNT(*) as count FROM enrollments 
      WHERE user_id = ? AND status = 'completed'
    `).get(req.user.id).count

    // Total exercises completed
    const exercisesCompleted = db.prepare(`
      SELECT COUNT(*) as count FROM submissions 
      WHERE user_id = ? AND status = 'passed'
    `).get(req.user.id).count

    // Calculate study hours (rough estimate: 10 min per completed lesson)
    const studyHours = Math.round(lessonsCompleted * 10 / 60)

    // Total points
    const pointsResult = db.prepare(`
      SELECT COALESCE(SUM(points_earned), 0) as total FROM submissions 
      WHERE user_id = ?
    `).get(req.user.id)
    const totalPoints = pointsResult.total

    // Calculate rank
    const rankResult = db.prepare(`
      SELECT COUNT(*) + 1 as rank FROM (
        SELECT user_id, SUM(points_earned) as points 
        FROM submissions 
        GROUP BY user_id 
        HAVING points > ?
      )
    `).get(totalPoints)
    const rank = rankResult.rank

    // Activity for last 30 days
    const activity = db.prepare(`
      SELECT DATE(submitted_at) as date, COUNT(*) as count
      FROM submissions
      WHERE user_id = ? AND submitted_at >= DATE('now', '-30 days')
      GROUP BY DATE(submitted_at)
      ORDER BY date
    `).all(req.user.id)

    // Recent activity
    const recentActivity = db.prepare(`
      SELECT 'submission' as type, s.submitted_at as time, 
        CASE s.status WHEN 'passed' THEN 'Выполнено упражнение' ELSE 'Отправлено решение' END as action,
        COALESCE(l.title, 'Задание') as item
      FROM submissions s
      LEFT JOIN exercises e ON s.exercise_id = e.id
      LEFT JOIN lessons l ON e.lesson_id = l.id
      WHERE s.user_id = ?
      UNION ALL
      SELECT 'lesson' as type, lp.completed_at as time, 
        'Пройден урок' as action, l.title as item
      FROM lesson_progress lp
      JOIN lessons l ON lp.lesson_id = l.id
      WHERE lp.user_id = ? AND lp.status = 'completed' AND lp.completed_at IS NOT NULL
      ORDER BY time DESC
      LIMIT 10
    `).all(req.user.id, req.user.id)

    res.json({
      lessonsCompleted,
      coursesCompleted,
      exercisesCompleted,
      studyHours,
      totalPoints,
      rank,
      activity,
      recentActivity
    })
  } catch (error) {
    console.error('Get stats error:', error)
    res.status(500).json({ error: 'Ошибка получения статистики' })
  }
})

// Get leaderboard
router.get('/leaderboard', (req, res) => {
  try {
    const { period = 'week', limit = 15 } = req.query
    
    let dateFilter = ''
    if (period === 'week') {
      dateFilter = "AND submitted_at >= DATE('now', '-7 days')"
    } else if (period === 'month') {
      dateFilter = "AND submitted_at >= DATE('now', '-30 days')"
    }

    const leaderboard = db.prepare(`
      SELECT u.id, u.name, u.avatar, 
        COALESCE(SUM(s.points_earned), 0) as points,
        COUNT(CASE WHEN s.status = 'passed' THEN 1 END) as solved
      FROM users u
      LEFT JOIN submissions s ON u.id = s.user_id ${dateFilter}
      WHERE u.role = 'student'
      GROUP BY u.id
      HAVING points > 0
      ORDER BY points DESC
      LIMIT ?
    `).all(Number(limit))

    res.json(leaderboard.map((user, index) => ({
      pos: index + 1,
      id: user.id,
      name: user.name,
      avatar: user.avatar,
      points: user.points,
      solved: user.solved
    })))
  } catch (error) {
    console.error('Get leaderboard error:', error)
    res.status(500).json({ error: 'Ошибка получения рейтинга' })
  }
})

// Get discussions
router.get('/discussions', (req, res) => {
  try {
    const { course_id, page = 1, limit = 20 } = req.query
    
    // Validate and sanitize pagination parameters
    const pageNum = Math.max(1, Math.min(100, Number(page) || 1))
    const limitNum = Math.max(1, Math.min(100, Number(limit) || 20))
    const offset = (pageNum - 1) * limitNum

    let query = `
      SELECT d.*, u.name as author_name, u.avatar as author_avatar,
        c.title as course_title,
        (SELECT COUNT(*) FROM discussion_replies WHERE discussion_id = d.id) as replies_count
      FROM discussions d
      JOIN users u ON d.user_id = u.id
      LEFT JOIN courses c ON d.course_id = c.id
    `
    const params = []

    if (course_id) {
      // Validate UUID format
      if (!validateUUID(course_id)) {
        return res.status(400).json({ error: 'Некорректный ID курса' })
      }
      query += ' WHERE d.course_id = ?'
      params.push(course_id)
    }

    query += ' ORDER BY d.created_at DESC LIMIT ? OFFSET ?'
    params.push(limitNum, offset)

    const discussions = db.prepare(query).all(...params)

    res.json(discussions.map(d => ({
      id: d.id,
      title: d.title,
      content: d.content,
      course: d.course_title,
      course_id: d.course_id,
      author: d.author_name,
      author_avatar: d.author_avatar,
      replies: d.replies_count,
      created_at: d.created_at,
      time: formatTimeAgo(d.created_at)
    })))
  } catch (error) {
    console.error('Get discussions error:', error)
    res.status(500).json({ error: 'Ошибка получения обсуждений' })
  }
})

// Create discussion
router.post('/discussions', authenticate, (req, res) => {
  try {
    const { title, content, course_id } = req.body
    
    // Validate and sanitize input
    const sanitizedTitle = validateTitle(title)
    const sanitizedContent = validateContent(content)
    
    // Validate course_id if provided
    let validCourseId = null
    if (course_id) {
      if (!validateUUID(course_id)) {
        return res.status(400).json({ error: 'Некорректный ID курса' })
      }
      // Verify course exists
      const course = db.prepare('SELECT id FROM courses WHERE id = ?').get(course_id)
      if (!course) {
        return res.status(404).json({ error: 'Курс не найден' })
      }
      validCourseId = course_id
    }
    
    const id = uuid()

    db.prepare(`
      INSERT INTO discussions (id, user_id, course_id, title, content)
      VALUES (?, ?, ?, ?, ?)
    `).run(id, req.user.id, validCourseId, sanitizedTitle, sanitizedContent)

    // Get created discussion with author info
    const discussion = db.prepare(`
      SELECT d.*, u.name as author_name, u.avatar as author_avatar,
        c.title as course_title,
        (SELECT COUNT(*) FROM discussion_replies WHERE discussion_id = d.id) as replies_count
      FROM discussions d
      JOIN users u ON d.user_id = u.id
      LEFT JOIN courses c ON d.course_id = c.id
      WHERE d.id = ?
    `).get(id)

    res.status(201).json({
      id: discussion.id,
      title: discussion.title,
      content: discussion.content,
      course: discussion.course_title,
      course_id: discussion.course_id,
      author: discussion.author_name,
      author_avatar: discussion.author_avatar,
      replies: discussion.replies_count,
      created_at: discussion.created_at,
      time: formatTimeAgo(discussion.created_at)
    })
  } catch (error) {
    console.error('Create discussion error:', error)
    if (error.message && (error.message.includes('обязателен') || error.message.includes('должен') || error.message.includes('не должен'))) {
      return res.status(400).json({ error: error.message })
    }
    res.status(500).json({ error: 'Ошибка создания обсуждения' })
  }
})

// Get single discussion with replies
router.get('/discussions/:id', (req, res) => {
  try {
    const { id } = req.params
    
    // Validate UUID format
    if (!validateUUID(id)) {
      return res.status(400).json({ error: 'Некорректный ID обсуждения' })
    }

    // Get discussion
    const discussion = db.prepare(`
      SELECT d.*, u.name as author_name, u.avatar as author_avatar,
        c.title as course_title,
        (SELECT COUNT(*) FROM discussion_replies WHERE discussion_id = d.id) as replies_count
      FROM discussions d
      JOIN users u ON d.user_id = u.id
      LEFT JOIN courses c ON d.course_id = c.id
      WHERE d.id = ?
    `).get(id)

    if (!discussion) {
      return res.status(404).json({ error: 'Обсуждение не найдено' })
    }

    // Get replies
    const replies = db.prepare(`
      SELECT dr.*, u.name as author_name, u.avatar as author_avatar
      FROM discussion_replies dr
      JOIN users u ON dr.user_id = u.id
      WHERE dr.discussion_id = ?
      ORDER BY dr.created_at ASC
    `).all(id)

    res.json({
      id: discussion.id,
      title: discussion.title,
      content: discussion.content,
      course: discussion.course_title,
      course_id: discussion.course_id,
      author: discussion.author_name,
      author_avatar: discussion.author_avatar,
      replies: discussion.replies_count,
      created_at: discussion.created_at,
      time: formatTimeAgo(discussion.created_at),
      replies_list: replies.map(r => ({
        id: r.id,
        content: r.content,
        author: r.author_name,
        author_avatar: r.author_avatar,
        created_at: r.created_at,
        time: formatTimeAgo(r.created_at)
      }))
    })
  } catch (error) {
    console.error('Get discussion error:', error)
    res.status(500).json({ error: 'Ошибка получения обсуждения' })
  }
})

// Create reply to discussion
router.post('/discussions/:id/replies', authenticate, (req, res) => {
  try {
    const { id } = req.params
    const { content } = req.body

    // Validate UUID format
    if (!validateUUID(id)) {
      return res.status(400).json({ error: 'Некорректный ID обсуждения' })
    }

    // Validate and sanitize content
    const sanitizedContent = validateContent(content)

    // Check if discussion exists
    const discussion = db.prepare('SELECT id FROM discussions WHERE id = ?').get(id)
    if (!discussion) {
      return res.status(404).json({ error: 'Обсуждение не найдено' })
    }

    const replyId = uuid()

    db.prepare(`
      INSERT INTO discussion_replies (id, discussion_id, user_id, content)
      VALUES (?, ?, ?, ?)
    `).run(replyId, id, req.user.id, sanitizedContent)

    // Get created reply with author info
    const reply = db.prepare(`
      SELECT dr.*, u.name as author_name, u.avatar as author_avatar
      FROM discussion_replies dr
      JOIN users u ON dr.user_id = u.id
      WHERE dr.id = ?
    `).get(replyId)

    res.status(201).json({
      id: reply.id,
      content: reply.content,
      author: reply.author_name,
      author_avatar: reply.author_avatar,
      created_at: reply.created_at,
      time: formatTimeAgo(reply.created_at)
    })
  } catch (error) {
    console.error('Create reply error:', error)
    if (error.message && (error.message.includes('обязателен') || error.message.includes('должен') || error.message.includes('не должен'))) {
      return res.status(400).json({ error: error.message })
    }
    res.status(500).json({ error: 'Ошибка создания ответа' })
  }
})

// Helper function
function formatTimeAgo(dateStr) {
  const date = new Date(dateStr)
  const now = new Date()
  const diff = now - date
  const minutes = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)
  const days = Math.floor(diff / 86400000)

  if (minutes < 60) return `${minutes} мин. назад`
  if (hours < 24) return `${hours} ч. назад`
  if (days === 1) return 'вчера'
  return `${days} дн. назад`
}

export default router

