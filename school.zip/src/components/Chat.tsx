import { useState, useEffect, useRef } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Send, Paperclip, ArrowLeft, Code, MoreVertical } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { chatAPI, createWebSocket } from '../api'
import type { Message, Chat } from '../api'

interface ChatPageProps {
  backLink?: string
}

export default function ChatPage({ backLink = '/dashboard' }: ChatPageProps) {
  const { chatId } = useParams()
  const { user, token } = useAuth()
  const [chats, setChats] = useState<Chat[]>([])
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [activeChat, setActiveChat] = useState<Chat | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const wsRef = useRef<WebSocket | null>(null)

  // Load chats
  useEffect(() => {
    chatAPI.getChats().then(setChats)
  }, [])

  // WebSocket connection
  useEffect(() => {
    if (token) {
      const ws = createWebSocket(token)
      
      ws.onmessage = (event) => {
        const data = JSON.parse(event.data)
        
        if (data.type === 'new_message') {
          if (data.message.chat_id === chatId) {
            setMessages(prev => [...prev, data.message])
            scrollToBottom()
          }
          // Update chat list
          setChats(prev => prev.map(chat => 
            chat.id === data.message.chat_id 
              ? { ...chat, last_message: data.message.content, unread_count: chat.unread_count + 1 }
              : chat
          ))
        }
      }

      wsRef.current = ws

      return () => {
        ws.close()
      }
    }
  }, [token, chatId])

  // Load messages for selected chat
  useEffect(() => {
    if (chatId) {
      chatAPI.getMessages(chatId).then(msgs => {
        setMessages(msgs)
        scrollToBottom()
      })
      
      const chat = chats.find(c => c.id === chatId)
      setActiveChat(chat || null)
    }
  }, [chatId, chats])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const handleSend = async () => {
    if (!newMessage.trim() || !chatId) return

    const messageType = newMessage.includes('```') ? 'code' : 'text'
    
    try {
      const message = await chatAPI.sendMessage(chatId, newMessage, messageType)
      setMessages(prev => [...prev, message])
      setNewMessage('')
      scrollToBottom()
    } catch (error) {
      console.error('Failed to send message:', error)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const getOtherParticipant = (chat: Chat) => {
    return chat.participants.find(p => p.id !== user?.id)
  }

  return (
    <div className="flex h-screen bg-white">
      {/* Chat List */}
      <div className="w-80 border-r flex flex-col">
        <div className="p-4 border-b">
          <Link to={backLink} className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4">
            <ArrowLeft className="w-5 h-5" />
            Назад
          </Link>
          <h2 className="text-lg font-semibold">Сообщения</h2>
        </div>

        <div className="flex-1 overflow-y-auto">
          {chats.map((chat) => {
            const other = getOtherParticipant(chat)
            const isActive = chat.id === chatId
            return (
              <Link
                key={chat.id}
                to={`${backLink}/chat/${chat.id}`}
                className={`flex items-center gap-3 p-4 hover:bg-gray-50 border-b ${
                  isActive ? 'bg-blue-50' : ''
                }`}
              >
                <div className="relative">
                  <img src={other?.avatar} alt="" className="w-12 h-12 rounded-full" />
                  {chat.unread_count > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-blue-600 text-white text-xs rounded-full flex items-center justify-center">
                      {chat.unread_count}
                    </span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{other?.name}</div>
                  <div className="text-sm text-gray-500 truncate">{chat.last_message}</div>
                </div>
              </Link>
            )
          })}
        </div>
      </div>

      {/* Chat Messages */}
      {chatId && activeChat ? (
        <div className="flex-1 flex flex-col">
          {/* Chat Header */}
          <div className="p-4 border-b flex items-center gap-4">
            <img 
              src={getOtherParticipant(activeChat)?.avatar} 
              alt="" 
              className="w-10 h-10 rounded-full" 
            />
            <div className="flex-1">
              <div className="font-medium">{getOtherParticipant(activeChat)?.name}</div>
              <div className="text-sm text-gray-500">
                {getOtherParticipant(activeChat)?.role === 'teacher' ? 'Преподаватель' : 'Студент'}
              </div>
            </div>
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <MoreVertical className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => {
              const isOwn = message.sender_id === user?.id
              return (
                <div
                  key={message.id}
                  className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex gap-2 max-w-[70%] ${isOwn ? 'flex-row-reverse' : ''}`}>
                    {!isOwn && (
                      <img src={message.sender_avatar} alt="" className="w-8 h-8 rounded-full" />
                    )}
                    <div>
                      {!isOwn && (
                        <div className="text-xs text-gray-500 mb-1">{message.sender_name}</div>
                      )}
                      <div className={`rounded-2xl px-4 py-2 ${
                        isOwn 
                          ? 'bg-blue-600 text-white' 
                          : 'bg-gray-100 text-gray-900'
                      }`}>
                        {message.message_type === 'code' ? (
                          <pre className={`text-sm font-mono whitespace-pre-wrap ${
                            isOwn ? 'bg-blue-700' : 'bg-gray-200'
                          } rounded p-2 mt-1`}>
                            {message.content}
                          </pre>
                        ) : (
                          <p className="whitespace-pre-wrap">{message.content}</p>
                        )}
                      </div>
                      <div className={`text-xs text-gray-400 mt-1 ${isOwn ? 'text-right' : ''}`}>
                        {new Date(message.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t">
            <div className="flex items-center gap-2">
              <button className="p-2 hover:bg-gray-100 rounded-full">
                <Paperclip className="w-5 h-5 text-gray-500" />
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-full">
                <Code className="w-5 h-5 text-gray-500" />
              </button>
              <textarea
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Написать сообщение..."
                className="flex-1 px-4 py-2 border rounded-full resize-none max-h-32"
                rows={1}
              />
              <button
                onClick={handleSend}
                disabled={!newMessage.trim()}
                className="p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 disabled:opacity-50"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center text-gray-500">
          Выберите чат
        </div>
      )}
    </div>
  )
}

// Start Chat Button
export function StartChatButton({ userId, userName }: { userId: string; userName: string }) {
  const [loading, setLoading] = useState(false)

  const handleStartChat = async () => {
    setLoading(true)
    try {
      const chat = await chatAPI.createDirect(userId)
      window.location.href = `/dashboard/chat/${chat.id}`
    } catch (error) {
      console.error('Failed to create chat:', error)
    }
    setLoading(false)
  }

  return (
    <button
      onClick={handleStartChat}
      disabled={loading}
      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
    >
      {loading ? 'Открытие...' : `Написать ${userName}`}
    </button>
  )
}

