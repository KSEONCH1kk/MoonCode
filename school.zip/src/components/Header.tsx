import { useState, useRef, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Menu, X, ChevronDown, Search, Bell, Moon, Sparkles } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'

// Course categories
const categories = [
  'Программирование',
  'Data Science',
  'DevOps',
  'Тестирование',
  'Дизайн',
  'Менеджмент'
]

export function Header() {
  const { user, logout } = useAuth()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [coursesDropdown, setCoursesDropdown] = useState(false)
  const [aboutDropdown, setAboutDropdown] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const coursesRef = useRef<HTMLDivElement>(null)
  const aboutRef = useRef<HTMLDivElement>(null)
  const userRef = useRef<HTMLDivElement>(null)
  const navigate = useNavigate()
  
  // Check if user is logged in
  const isLoggedIn = !!user

  // Close dropdowns on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (coursesRef.current && !coursesRef.current.contains(event.target as Node)) {
        setCoursesDropdown(false)
      }
      if (aboutRef.current && !aboutRef.current.contains(event.target as Node)) {
        setAboutDropdown(false)
      }
      if (userRef.current && !userRef.current.contains(event.target as Node)) {
        setUserMenuOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleCategoryClick = (category: string) => {
    setCoursesDropdown(false)
    navigate(`/courses?category=${encodeURIComponent(category)}`)
  }

  return (
    <header className="border-b border-gray-200 bg-white sticky top-0 z-50">
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-1.5">
              <svg width="28" height="28" viewBox="0 0 32 32" fill="none">
                <rect width="32" height="32" rx="8" fill="#111827"/>
                <path d="M8 10h4v12H8V10zm6 4h4v8h-4v-8zm6-2h4v10h-4V12z" fill="white"/>
              </svg>
              <span className="text-[20px] font-medium text-gray-900 tracking-tight">Хекслет</span>
            </Link>
            
            <nav className="hidden md:flex items-center gap-1">
              {/* My Learning (logged in) */}
              {isLoggedIn && (
                <Link to="/dashboard" className="px-3 py-2 text-sm text-gray-600 hover:text-gray-900">
                  Мое обучение
                </Link>
              )}
              
              {/* Courses Dropdown */}
              <div ref={coursesRef} className="relative">
                <button 
                  className="flex items-center gap-1 px-3 py-2 text-sm text-gray-600 hover:text-gray-900"
                  onClick={() => setCoursesDropdown(!coursesDropdown)}
                >
                  Все курсы <ChevronDown className={`w-4 h-4 transition-transform ${coursesDropdown ? 'rotate-180' : ''}`} />
                </button>
                
                {coursesDropdown && (
                  <div className="absolute top-full left-0 mt-1 w-[600px] bg-white rounded-xl shadow-xl border border-gray-200 p-6 grid grid-cols-2 gap-6">
                    <div>
                      <div className="text-xs font-medium text-gray-400 uppercase tracking-wider mb-3">Направления</div>
                      <div className="space-y-1">
                        {categories.map(cat => (
                          <button
                            key={cat}
                            onClick={() => handleCategoryClick(cat)}
                            className="block w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
                          >
                            {cat}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs font-medium text-gray-400 uppercase tracking-wider mb-3">Популярные</div>
                      <div className="space-y-1">
                        <Link to="/courses/python-developer" onClick={() => setCoursesDropdown(false)} className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg">Python-разработчик</Link>
                        <Link to="/courses/frontend-developer" onClick={() => setCoursesDropdown(false)} className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg">Frontend-разработчик</Link>
                        <Link to="/courses/java-developer" onClick={() => setCoursesDropdown(false)} className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg">Java-разработчик</Link>
                        <Link to="/courses/devops-engineer" onClick={() => setCoursesDropdown(false)} className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg">DevOps-инженер</Link>
                      </div>
                      <Link 
                        to="/courses" 
                        onClick={() => setCoursesDropdown(false)}
                        className="block mt-4 px-3 py-2 text-sm font-medium text-gray-900 hover:bg-gray-100 rounded-lg"
                      >
                        Все курсы →
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* About Dropdown */}
              <div ref={aboutRef} className="relative">
                <button 
                  className="flex items-center gap-1 px-3 py-2 text-sm text-gray-600 hover:text-gray-900"
                  onClick={() => setAboutDropdown(!aboutDropdown)}
                >
                  О Хекслете <ChevronDown className={`w-4 h-4 transition-transform ${aboutDropdown ? 'rotate-180' : ''}`} />
                </button>
                
                {aboutDropdown && (
                  <div className="absolute top-full left-0 mt-1 w-[280px] bg-white rounded-xl shadow-xl border border-gray-200 p-4">
                    <div className="space-y-1">
                      <a href="#" className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg">О школе</a>
                      <a href="#" className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg">Отзывы выпускников</a>
                      <a href="#" className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg">Корпоративное обучение</a>
                      <a href="#" className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg">Блог</a>
                      <a href="#" className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg">Вопросы и ответы</a>
                    </div>
                  </div>
                )}
              </div>

              <Link to="/courses" className="px-3 py-2 text-sm text-gray-600 hover:text-gray-900">Подписка</Link>
              <a href="#" className="px-3 py-2 text-sm font-medium text-gray-900">-30% New Year →</a>
            </nav>
          </div>
          
          <div className="hidden md:flex items-center gap-3">
            {isLoggedIn ? (
              <>
                {/* Tota AI Button */}
                <button className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-300 rounded-lg text-sm text-gray-600 hover:border-gray-400 transition-colors">
                  <Sparkles className="w-4 h-4" />
                  Tota ИИ
                </button>
                
                {/* Notifications */}
                <button className="p-2 text-gray-500 hover:text-gray-900 relative">
                  <Bell className="w-5 h-5" />
                </button>
                
                {/* Theme Toggle */}
                <button className="p-2 text-gray-500 hover:text-gray-900">
                  <Moon className="w-5 h-5" />
                </button>
                
                {/* User Menu */}
                <div ref={userRef} className="relative">
                  <button 
                    onClick={() => setUserMenuOpen(!userMenuOpen)}
                    className="flex items-center gap-2"
                  >
                    <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center text-white text-sm font-medium">
                      С
                    </div>
                    <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${userMenuOpen ? 'rotate-180' : ''}`} />
                  </button>
                  
                  {userMenuOpen && (
                    <div className="absolute top-full right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-200 py-2">
                      <Link to="/dashboard" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">Мой профиль</Link>
                      <Link to="/dashboard/courses" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">Мои курсы</Link>
                      <Link to="/dashboard/rating" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">Рейтинг</Link>
                      <div className="border-t border-gray-100 my-1" />
                      <button onClick={logout} className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-50">Выйти</button>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <>
                <button className="p-2 text-gray-500 hover:text-gray-900">
                  <Search className="w-5 h-5" />
                </button>
                <Link to="/register" className="text-sm text-gray-600 hover:text-gray-900">Регистрация</Link>
                <Link to="/login" className="text-sm text-gray-600 hover:text-gray-900">Вход</Link>
              </>
            )}
          </div>
          
          <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-gray-200 bg-white">
          <div className="p-4 space-y-2">
            <Link to="/courses" className="block py-3 text-gray-700 font-medium border-b border-gray-100">Все курсы</Link>
            <div className="py-2 space-y-1">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => {
                    setMobileMenuOpen(false)
                    navigate(`/courses?category=${encodeURIComponent(cat)}`)
                  }}
                  className="block w-full text-left py-2 pl-4 text-sm text-gray-500"
                >
                  {cat}
                </button>
              ))}
            </div>
            <Link to="/login" className="block py-3 text-gray-700 border-t border-gray-100">Вход</Link>
            <Link to="/register" className="block py-3 text-gray-700">Регистрация</Link>
          </div>
        </div>
      )}
    </header>
  )
}

