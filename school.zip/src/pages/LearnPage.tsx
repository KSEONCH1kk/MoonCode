import { useState, useEffect, useRef } from 'react'
import { Link, useParams, useNavigate } from 'react-router-dom'
import { 
  Home, BarChart2, BookOpen, MessageCircle, Trophy, Users, UserPlus,
  ChevronDown, Play, FileText, Code, CheckCircle, Circle, ArrowRight,
  Calendar, HelpCircle, Pause, Volume2, VolumeX, Maximize, SkipBack, SkipForward
} from 'lucide-react'
import Editor from '@monaco-editor/react'
import { getLanguageFromFilename, initializeMonaco } from '../monaco-config'
import { executeCode, lintCode, healthCheck, getLanguageFromExtension } from '../api/codeRunner'
import { userAPI } from '../api'
import type { UserEnrollment, UserStats, Discussion, DiscussionDetail } from '../api'

// Initialize Monaco with all language support
initializeMonaco()

// Custom Video Player Component
function VideoPlayer({ url, title, duration }: { url?: string; title: string; duration?: number }) {
  const containerRef = useRef<HTMLDivElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [totalDuration, setTotalDuration] = useState(0)
  const [volume, setVolume] = useState(1)
  const [isMuted, setIsMuted] = useState(false)
  const [showControls, setShowControls] = useState(true)
  const [isFullscreen, setIsFullscreen] = useState(false)

  // Listen for fullscreen changes
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }
    document.addEventListener('fullscreenchange', handleFullscreenChange)
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange)
  }, [])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime)
    }
  }

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setTotalDuration(videoRef.current.duration)
    }
  }

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = Number(e.target.value)
    if (videoRef.current) {
      videoRef.current.currentTime = time
      setCurrentTime(time)
    }
  }

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = Number(e.target.value)
    setVolume(vol)
    if (videoRef.current) {
      videoRef.current.volume = vol
    }
    setIsMuted(vol === 0)
  }

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  const toggleFullscreen = () => {
    if (containerRef.current) {
      if (!document.fullscreenElement) {
        containerRef.current.requestFullscreen()
      } else {
        document.exitFullscreen()
      }
    }
  }

  const skip = (seconds: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime += seconds
    }
  }

  // If no URL, show placeholder
  if (!url) {
    return (
      <div className="aspect-video bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl mb-8 flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(59,130,246,0.1),transparent)]" />
        <div className="text-center text-white z-10">
          <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-white/10 flex items-center justify-center">
            <Play className="w-10 h-10 text-white/80" />
          </div>
          <p className="text-xl font-medium">{title}</p>
          <p className="text-sm text-gray-400 mt-2">Видео скоро будет добавлено</p>
          {duration && <p className="text-xs text-gray-500 mt-1">Длительность: ~{duration} мин</p>}
        </div>
      </div>
    )
  }

  // Check if it's a YouTube URL
  const isYouTube = url.includes('youtube.com') || url.includes('youtu.be')
  
  // For YouTube, convert to embed URL
  if (isYouTube) {
    let embedUrl = url
    
    // Already an embed URL
    if (url.includes('/embed/')) {
      embedUrl = url
    }
    // Standard watch URL: https://www.youtube.com/watch?v=VIDEO_ID
    else if (url.includes('watch?v=')) {
      const videoId = url.split('watch?v=')[1]?.split('&')[0]
      embedUrl = `https://www.youtube.com/embed/${videoId}`
    }
    // Short URL: https://youtu.be/VIDEO_ID
    else if (url.includes('youtu.be/')) {
      const videoId = url.split('youtu.be/')[1]?.split('?')[0]
      embedUrl = `https://www.youtube.com/embed/${videoId}`
    }
    // Just video ID
    else if (url.match(/^[a-zA-Z0-9_-]{11}$/)) {
      embedUrl = `https://www.youtube.com/embed/${url}`
    }
    
    return (
      <div className="aspect-video bg-gray-900 rounded-xl mb-8 overflow-hidden">
        <iframe 
          src={embedUrl}
          className="w-full h-full border-0"
          allowFullScreen
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          referrerPolicy="strict-origin-when-cross-origin"
        />
      </div>
    )
  }

  // Custom video player for direct video files
  return (
    <div 
      ref={containerRef}
      className={`bg-black rounded-xl mb-8 relative overflow-hidden group ${isFullscreen ? 'fixed inset-0 z-50 rounded-none mb-0' : 'aspect-video'}`}
      onMouseEnter={() => setShowControls(true)}
      onMouseLeave={() => isPlaying && setShowControls(false)}
    >
      <video
        ref={videoRef}
        src={url}
        className={`w-full h-full object-contain ${isFullscreen ? '' : ''}`}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onEnded={() => setIsPlaying(false)}
        onClick={togglePlay}
      />
      
      {/* Play overlay */}
      {!isPlaying && (
        <div 
          className="absolute inset-0 flex items-center justify-center bg-black/30 cursor-pointer"
          onClick={togglePlay}
        >
          <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center hover:bg-white/30 transition-colors">
            <Play className="w-10 h-10 text-white ml-1" />
          </div>
        </div>
      )}
      
      {/* Controls - fixed at bottom */}
      <div className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-4 pb-6 transition-opacity z-10 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        {/* Progress bar */}
        <div className="flex items-center gap-3 mb-4">
          <span className="text-white text-sm font-mono w-14">{formatTime(currentTime)}</span>
          <input
            type="range"
            min={0}
            max={totalDuration || 100}
            value={currentTime}
            onChange={handleSeek}
            className="flex-1 h-1.5 bg-white/30 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:shadow-lg"
          />
          <span className="text-white text-sm font-mono w-14 text-right">{formatTime(totalDuration)}</span>
        </div>
        
        {/* Control buttons */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1">
            <button onClick={() => skip(-10)} className="p-2.5 text-white hover:bg-white/20 rounded-lg transition-colors">
              <SkipBack className="w-5 h-5" />
            </button>
            <button onClick={togglePlay} className="p-3 text-white hover:bg-white/20 rounded-lg transition-colors">
              {isPlaying ? <Pause className="w-7 h-7" /> : <Play className="w-7 h-7" />}
            </button>
            <button onClick={() => skip(10)} className="p-2.5 text-white hover:bg-white/20 rounded-lg transition-colors">
              <SkipForward className="w-5 h-5" />
            </button>
            
            <div className="flex items-center gap-2 ml-4">
              <button onClick={toggleMute} className="p-2.5 text-white hover:bg-white/20 rounded-lg transition-colors">
                {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.1}
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-24 h-1.5 bg-white/30 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:rounded-full"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <span className="text-white text-sm hidden sm:block">{title}</span>
            <button onClick={toggleFullscreen} className="p-2.5 text-white hover:bg-white/20 rounded-lg transition-colors">
              <Maximize className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

// Sidebar for learning
function LearnSidebar({ active = 'learn' }: { active?: string }) {
  const links = [
    { to: '/learn', id: 'learn', icon: Home, label: 'Обучение' },
    { to: '/learn/progress', id: 'progress', icon: BarChart2, label: 'Прогресс' },
    { to: '/learn/courses', id: 'courses', icon: BookOpen, label: 'Курсы' },
    { to: '/dashboard/solutions', id: 'grades', icon: Trophy, label: 'Мои оценки' },
    { to: '/learn/discussions', id: 'discussions', icon: MessageCircle, label: 'Обсуждения' },
  ]

  return (
    <aside className="w-[200px] border-r border-gray-200 bg-white shrink-0">
      <nav className="p-4 space-y-1">
        {links.map(link => (
          <Link 
            key={link.id}
            to={link.to} 
            className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm ${
              active === link.id 
                ? 'text-gray-900 bg-gray-100 font-medium' 
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            <link.icon className="w-5 h-5" />
            {link.label}
          </Link>
        ))}
        
        <div className="border-t border-gray-200 my-4" />
        
        <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-gray-600 hover:bg-gray-50">
          <Users className="w-5 h-5" />
          Партнерка
        </a>
        <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-gray-600 hover:bg-gray-50">
          <UserPlus className="w-5 h-5" />
          Команда
        </a>
      </nav>
    </aside>
  )
}

// Course Roadmap Page
export function LearnRoadmap() {
  const [courseDropdown, setCourseDropdown] = useState(false)
  const [enrollments, setEnrollments] = useState<UserEnrollment[]>([])
  const [currentCourse, setCurrentCourse] = useState<any>(null)
  const [modules, setModules] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [firstLessonId, setFirstLessonId] = useState<string | null>(null)
  const navigate = useNavigate()

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) {
        setLoading(false)
        return
      }

      const data = await userAPI.getEnrollments()
      setEnrollments(data || [])
      
      if (data && data.length > 0) {
        // Load course details for first enrollment
        const courseDetails = await fetch(`http://localhost:3001/api/courses/${data[0].course.slug}`, {
          headers: { 'Authorization': `Bearer ${token}` }
        }).then(r => r.json())
        
        setCurrentCourse({
          ...data[0].course,
          progress: data[0].progress,
          modules: courseDetails.modules || []
        })
        setModules(courseDetails.modules || [])
        
        // Get first lesson ID
        if (courseDetails.modules?.length > 0 && courseDetails.modules[0].lessons?.length > 0) {
          setFirstLessonId(courseDetails.modules[0].lessons[0].id)
        }
      }
    } catch (error) {
      console.error('Failed to load courses:', error)
    }
    setLoading(false)
  }

  const selectCourse = async (enrollment: UserEnrollment) => {
    try {
      const token = localStorage.getItem('token')
      const courseDetails = await fetch(`http://localhost:3001/api/courses/${enrollment.course.slug}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      }).then(r => r.json())
      
      setCurrentCourse({
        ...enrollment.course,
        progress: enrollment.progress,
        modules: courseDetails.modules || []
      })
      setModules(courseDetails.modules || [])
      
      if (courseDetails.modules?.length > 0 && courseDetails.modules[0].lessons?.length > 0) {
        setFirstLessonId(courseDetails.modules[0].lessons[0].id)
      }
    } catch (error) {
      console.error('Failed to load course:', error)
    }
    setCourseDropdown(false)
  }

  const getLessonIcon = (type: string, completed: boolean) => {
    if (completed) return <CheckCircle className="w-5 h-5 text-blue-500" />
    if (type === 'video') return <Play className="w-5 h-5 text-gray-400" />
    if (type === 'theory') return <FileText className="w-5 h-5 text-gray-400" />
    if (type === 'practice') return <Code className="w-5 h-5 text-gray-400" />
    if (type === 'quiz') return <HelpCircle className="w-5 h-5 text-gray-400" />
    return <Circle className="w-5 h-5 text-gray-400" />
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex">
        <LearnSidebar />
        <main className="flex-1 p-8 flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full"></div>
        </main>
      </div>
    )
  }

  // If no enrollments, show empty state
  if (enrollments.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex">
        <LearnSidebar />
        <main className="flex-1 p-8 flex items-center justify-center">
          <div className="text-center">
            <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h2 className="text-xl font-medium text-gray-900 mb-2">Нет активных курсов</h2>
            <p className="text-gray-500 mb-6">Запишитесь на курс, чтобы начать обучение</p>
            <Link 
              to="/courses" 
              className="inline-flex items-center gap-2 px-6 py-3 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600"
            >
              Выбрать курс <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <LearnSidebar />
      
      <main className="flex-1 p-8">
        {/* Course Selector */}
        <div className="relative inline-block mb-8">
          <button 
            onClick={() => setCourseDropdown(!courseDropdown)}
            className="flex items-center gap-2 text-2xl font-medium text-gray-900"
          >
            {currentCourse?.title || 'Выберите курс'}
            <ChevronDown className={`w-5 h-5 transition-transform ${courseDropdown ? 'rotate-180' : ''}`} />
          </button>
          {courseDropdown && (
            <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-gray-200 py-2 z-10">
              {enrollments.map(e => (
                <button 
                  key={e.id}
                  onClick={() => selectCourse(e)}
                  className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 ${
                    currentCourse?.id === e.course.id ? 'bg-blue-50 text-blue-700' : 'text-gray-700'
                  }`}
                >
                  {e.course.title}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Promo Banner */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 mb-8 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
              <Calendar className="w-6 h-6 text-yellow-600" />
            </div>
            <div>
              <div className="font-medium text-gray-900">Групповое обучение с наставником</div>
              <div className="text-sm text-gray-500">Ревью проектов, вебинары, поддержка преподавателя</div>
            </div>
          </div>
          <Link to="/courses" className="px-6 py-2.5 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50">
            Все курсы
          </Link>
        </div>

        {/* Course Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Current Course */}
          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-xl font-medium text-gray-900">{currentCourse?.title || 'Курс'}</h3>
                <p className="text-sm text-gray-500">{currentCourse?.duration_hours || 0}ч обучения</p>
              </div>
              <div className="w-12 h-12 rounded-full border-4 border-orange-400 flex items-center justify-center text-sm font-medium text-orange-500">
                {currentCourse?.progress || 0}%
              </div>
            </div>
            
            {/* Progress bar */}
            <div className="flex gap-1 mb-4">
              {Array.from({ length: 20 }).map((_, i) => {
                const progress = currentCourse?.progress || 0
                const filled = i < Math.floor(progress / 5)
                return (
                  <div 
                    key={i} 
                    className={`h-1.5 flex-1 rounded-full ${filled ? 'bg-blue-500' : 'bg-gray-100'}`}
                  />
                )
              })}
            </div>

            <button 
              onClick={() => firstLessonId && navigate(`/learn/lesson/${firstLessonId}`)}
              disabled={!firstLessonId}
              className="flex items-center gap-2 px-5 py-2.5 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 disabled:opacity-50"
            >
              Учиться <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Project Card */}
          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-xl font-medium text-gray-900">Практический проект</h3>
                <p className="text-sm text-gray-500">Проект</p>
              </div>
              <div className="text-sm text-gray-500">0/5 этапов</div>
            </div>
            
            {/* Progress bar */}
            <div className="flex gap-1 mb-4">
              {Array.from({ length: 9 }).map((_, i) => (
                <div key={i} className="h-1.5 flex-1 rounded-full bg-gray-100" />
              ))}
            </div>

            <button 
              onClick={() => firstLessonId && navigate(`/learn/lesson/${firstLessonId}`)}
              disabled={!firstLessonId}
              className="flex items-center gap-2 px-5 py-2.5 bg-green-500 text-white rounded-lg text-sm font-medium hover:bg-green-600 disabled:opacity-50"
            >
              Кодить <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modules List */}
        {modules.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <p>Модули курса пока не добавлены</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-x-8 gap-y-4">
            {modules.map((module: any) => (
              <div key={module.id}>
                <h4 className="font-medium text-gray-900 mb-3">{module.title}</h4>
                <div className="space-y-2">
                  {(module.lessons || []).map((lesson: any) => (
                    <Link
                      key={lesson.id}
                      to={`/learn/lesson/${lesson.id}`}
                      className="flex items-center gap-3 py-1 text-sm text-gray-600 hover:text-gray-900"
                    >
                      {getLessonIcon(lesson.type, lesson.completed || false)}
                      <span className={lesson.completed ? 'text-gray-400' : ''}>{lesson.title}</span>
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}

// Lesson Page Layout
export function LessonPage() {
  const { lessonId } = useParams()
  const navigate = useNavigate()
  const [lessonData, setLessonData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isCompleted, setIsCompleted] = useState(false)
  const [completing, setCompleting] = useState(false)

  useEffect(() => {
    if (lessonId) {
      loadLesson()
    }
  }, [lessonId])

  const loadLesson = async () => {
    setLoading(true)
    setError(null)
    try {
      const token = localStorage.getItem('token')
      if (!token) {
        setError('Необходимо войти в систему')
        setLoading(false)
        return
      }

      const response = await fetch(`http://localhost:3001/api/courses/lessons/${lessonId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      
      if (!response.ok) {
        const err = await response.json()
        throw new Error(err.error || 'Ошибка загрузки урока')
      }
      
      const data = await response.json()
      setLessonData(data)
      setIsCompleted(data.progress?.status === 'completed')
    } catch (err: any) {
      console.error('Failed to load lesson:', err)
      setError(err.message || 'Урок не найден')
    }
    setLoading(false)
  }

  const markAsCompleted = async () => {
    if (!lessonId || isCompleted || completing) return
    
    setCompleting(true)
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`http://localhost:3001/api/courses/lessons/${lessonId}/complete`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      })
      
      if (response.ok) {
        setIsCompleted(true)
        // Update navigation progress
        if (lessonData?.navigation) {
          setLessonData({
            ...lessonData,
            navigation: {
              ...lessonData.navigation,
              current: lessonData.navigation.current + 1
            }
          })
        }
      }
    } catch (err) {
      console.error('Failed to mark as completed:', err)
    }
    setCompleting(false)
  }

  // Show loading
  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full"></div>
      </div>
    )
  }

  // Show error
  if (error || !lessonData) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center py-16">
          <h1 className="text-2xl font-medium text-gray-900 mb-4">{error || 'Урок не найден'}</h1>
          <p className="text-gray-500 mb-4">Возможно, вы не записаны на этот курс</p>
          <Link to="/learn" className="text-blue-500 hover:underline">Вернуться к курсу</Link>
        </div>
      </div>
    )
  }

  const { lesson, exercise, navigation, attachments = [] } = lessonData
  const progress = Math.round((navigation.current / navigation.total) * 100)

  // For practice lessons with exercise, show code editor
  if (lesson.type === 'practice' && exercise) {
    return <ExercisePage lessonData={lessonData} />
  }

  // Render lesson content based on type
  const renderLessonContent = () => {
    if (lesson.type === 'video') {
      return (
        <>
          <VideoPlayer 
            url={lesson.video_url} 
            title={lesson.title}
            duration={lesson.duration_minutes}
          />
          {lesson.content && (
            <div className="prose prose-gray max-w-none" dangerouslySetInnerHTML={{ __html: renderMarkdown(lesson.content) }} />
          )}
        </>
      )
    }

    if (lesson.type === 'theory') {
      return (
        <div className="prose prose-gray max-w-none">
          <h1>{lesson.title}</h1>
          {lesson.content ? (
            <div dangerouslySetInnerHTML={{ __html: renderMarkdown(lesson.content) }} />
          ) : (
            <p className="text-gray-500">Содержание урока будет добавлено позже.</p>
          )}
        </div>
      )
    }

    if (lesson.type === 'quiz') {
      return <QuizPage lesson={lesson} navigation={navigation} />
    }

    return (
      <div className="prose prose-gray max-w-none">
        <h1>{lesson.title}</h1>
        <p className="text-gray-500">Тип урока: {lesson.type}</p>
        {lesson.content && (
          <div dangerouslySetInnerHTML={{ __html: renderMarkdown(lesson.content) }} />
        )}
      </div>
    )
  }

  // Simple markdown renderer with XSS protection
  const renderMarkdown = (content: string) => {
    if (!content) return ''
    
    // First escape HTML to prevent XSS
    let html = content
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
    
    // Then apply markdown formatting (safe because HTML is already escaped)
    html = html
      .replace(/^### (.*$)/gim, '<h3>$1</h3>')
      .replace(/^## (.*$)/gim, '<h2>$1</h2>')
      .replace(/^# (.*$)/gim, '<h1>$1</h1>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>')
      .replace(/`(.*?)`/g, '<code>$1</code>')
      .replace(/^- (.*$)/gim, '<li>$1</li>')
      .replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>')
      .replace(/\n/g, '<br/>')
    
    // Final sanitization pass
    html = html
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/\s*on\w+\s*=\s*["'][^"']*["']/gi, '')
      .replace(/javascript:/gi, '')
    
    return html
  }

  return (
    <div className="min-h-screen bg-white flex">
      {/* Main Content */}
      <main className="flex-1 max-w-4xl mx-auto p-8">
        {/* Breadcrumb */}
        <div className="text-sm text-gray-500 mb-6">
          <Link to="/learn" className="hover:text-gray-700">{lesson.course_title}</Link>
          <span className="mx-2">→</span>
          <span>{lesson.module_title}</span>
        </div>

        {renderLessonContent()}

        {/* Mark as Completed Button for video/theory lessons */}
        {(lesson.type === 'video' || lesson.type === 'theory') && (
          <div className="mt-8 flex items-center justify-center gap-4">
            {isCompleted ? (
              <div className="flex items-center gap-2 text-green-600 font-medium">
                <CheckCircle className="w-6 h-6" />
                Урок пройден!
              </div>
            ) : (
              <button
                onClick={markAsCompleted}
                disabled={completing}
                className="px-6 py-3 bg-green-500 text-white rounded-lg font-medium hover:bg-green-600 disabled:opacity-50 flex items-center gap-2"
              >
                {completing ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Отмечаем...
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-5 h-5" />
                    Отметить урок как пройденный
                  </>
                )}
              </button>
            )}
          </div>
        )}

        {/* Materials */}
        {lesson.type !== 'quiz' && attachments && attachments.length > 0 && (
          <div className="mt-8 border-t border-gray-200 pt-8">
            <h3 className="font-medium text-gray-900 mb-4">📁 Материалы урока</h3>
            <div className="space-y-2">
              {attachments.map((file: any) => {
                const formatSize = (bytes: number) => {
                  if (bytes < 1024) return `${bytes} B`
                  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
                  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
                }
                
                const getFileIcon = (mimetype: string) => {
                  if (mimetype?.includes('pdf')) return '📕'
                  if (mimetype?.includes('word') || mimetype?.includes('document')) return '📘'
                  if (mimetype?.includes('sheet') || mimetype?.includes('excel')) return '📗'
                  if (mimetype?.includes('presentation') || mimetype?.includes('powerpoint')) return '📙'
                  if (mimetype?.includes('image')) return '🖼️'
                  if (mimetype?.includes('zip') || mimetype?.includes('rar') || mimetype?.includes('7z')) return '📦'
                  if (mimetype?.includes('video')) return '🎬'
                  return '📄'
                }
                
                return (
                  <a 
                    key={file.id}
                    href={`http://localhost:3001${file.url}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    download={file.original_name}
                    className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 hover:border-blue-300 transition-colors"
                  >
                    <span className="text-2xl">{getFileIcon(file.mimetype)}</span>
                    <span className="text-sm text-gray-700 flex-1">{file.original_name}</span>
                    <span className="text-xs text-gray-400">{formatSize(file.size)}</span>
                    <span className="text-xs text-blue-500">⬇ Скачать</span>
                  </a>
                )
              })}
            </div>
          </div>
        )}
      </main>

      {/* Right Sidebar */}
      <aside className="w-[280px] border-l border-gray-200 bg-white shrink-0">
        <div className="sticky top-0">
          <button 
            onClick={async () => {
              // Auto-mark as completed when going to next
              if (!isCompleted && (lesson.type === 'video' || lesson.type === 'theory')) {
                await markAsCompleted()
              }
              navigation.next ? navigate(`/learn/lesson/${navigation.next.id}`) : navigate('/learn')
            }}
            className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-orange-500 text-white font-medium hover:bg-orange-600"
          >
            {navigation.next ? 'Далее' : 'Завершить'} <ArrowRight className="w-4 h-4" />
          </button>

          <div className="p-4">
            <Link to="/learn" className="flex items-center gap-3 w-full px-3 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg">
              <Home className="w-5 h-5" />
              Навигация
            </Link>
            
            <div className="mt-4 px-3">
              <div className="text-sm text-gray-500">пройдено {navigation.current} урок из {navigation.total}</div>
              <div className="h-1 bg-gray-200 rounded-full mt-2">
                <div className="h-1 bg-green-500 rounded-full" style={{ width: `${progress}%` }} />
              </div>
            </div>

            <div className="mt-6 space-y-1">
              <div className="px-3 py-2 text-sm font-medium text-gray-900">
                Шаг: {lesson.type === 'video' ? 'видео' : lesson.type === 'quiz' ? 'тест' : lesson.type === 'practice' ? 'практика' : 'теория'}
              </div>
              <button className="w-full text-left px-3 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg">Обсуждение</button>
              <button className="w-full text-left px-3 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg">Теория</button>
              <button className="w-full text-left px-3 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg">Сложности и вопросы?</button>
            </div>

            {/* Navigation buttons */}
            <div className="mt-6 border-t border-gray-200 pt-4 space-y-2">
              {navigation.prev && (
                <Link
                  to={`/learn/lesson/${navigation.prev.id}`}
                  className="block w-full px-4 py-2 text-sm text-center border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  ← {navigation.prev.title}
                </Link>
              )}
              {navigation.next && (
                <Link
                  to={`/learn/lesson/${navigation.next.id}`}
                  className="block w-full px-4 py-2 text-sm text-center bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                >
                  {navigation.next.title} →
                </Link>
              )}
            </div>
          </div>
        </div>
      </aside>
    </div>
  )
}

// Learn Courses Page
export function LearnCourses() {
  const [enrollments, setEnrollments] = useState<UserEnrollment[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const data = await userAPI.getEnrollments()
      setEnrollments(data || [])
    } catch (error) {
      console.error('Failed to load courses:', error)
    }
    setLoading(false)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex">
        <LearnSidebar active="courses" />
        <main className="flex-1 p-8 flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full"></div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <LearnSidebar active="courses" />
      <main className="flex-1 p-8">
        <h1 className="text-2xl font-medium text-gray-900 mb-8">Мои курсы</h1>
        
        {enrollments.length === 0 ? (
          <div className="bg-white border border-gray-200 rounded-xl p-12 text-center">
            <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-xl font-medium text-gray-400 mb-2">Вы еще не записаны на курсы</h3>
            <p className="text-gray-400 mb-4">Выберите курс из каталога и начните обучение</p>
            <Link to="/courses" className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600">
              Перейти к курсам <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {enrollments.map(enrollment => (
              <Link 
                key={enrollment.id}
                to="/learn"
                className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-all"
              >
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded">{enrollment.course.category || 'Курс'}</span>
                  <span className="text-sm text-gray-500">{enrollment.course.level}</span>
                </div>
                <h3 className="font-medium text-gray-900 mb-4">{enrollment.course.title}</h3>
                <div className="flex items-center gap-3">
                  <div className="flex-1 h-2 bg-gray-200 rounded-full">
                    <div 
                      className={`h-2 rounded-full ${enrollment.progress === 100 ? 'bg-green-500' : 'bg-blue-500'}`}
                      style={{ width: `${enrollment.progress}%` }}
                    />
                  </div>
                  <span className="text-sm text-gray-500">{enrollment.progress}%</span>
                </div>
              </Link>
            ))}
          </div>
        )}

      </main>
    </div>
  )
}

// Learn Progress Page
export function LearnProgress() {
  const [loading, setLoading] = useState(true)
  const [userStats, setUserStats] = useState<UserStats | null>(null)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const data = await userAPI.getStats()
      setUserStats(data)
    } catch (error) {
      console.error('Failed to load stats:', error)
    }
    setLoading(false)
  }

  const stats = userStats ? [
    { label: 'Пройдено уроков', value: String(userStats.lessonsCompleted) },
    { label: 'Часов обучения', value: String(userStats.studyHours) },
    { label: 'Выполнено упражнений', value: String(userStats.exercisesCompleted) },
    { label: 'Завершено курсов', value: String(userStats.coursesCompleted) },
  ] : []

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex">
        <LearnSidebar active="progress" />
        <main className="flex-1 p-8 flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full"></div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <LearnSidebar active="progress" />
      <main className="flex-1 p-8">
        <h1 className="text-2xl font-medium text-gray-900 mb-8">Прогресс</h1>
        
        {/* Stats */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          {stats.map(stat => (
            <div key={stat.label} className="bg-white border border-gray-200 rounded-xl p-6">
              <div className="text-3xl font-medium text-gray-900 mb-1">{stat.value}</div>
              <div className="text-sm text-gray-500">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Activity Chart */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 mb-8">
          <h2 className="font-medium text-gray-900 mb-6">Активность за последние 30 дней</h2>
          <div className="flex items-end gap-1 h-32">
            {Array.from({ length: 30 }).map((_, i) => {
              // Find activity for this day
              const date = new Date()
              date.setDate(date.getDate() - (29 - i))
              const dateStr = date.toISOString().split('T')[0]
              const dayActivity = userStats?.activity?.find(a => a.date === dateStr)
              const height = dayActivity ? Math.min(dayActivity.count * 20, 100) : 5
              return (
                <div 
                  key={i}
                  className={`flex-1 rounded-t ${height > 5 ? 'bg-blue-500' : 'bg-gray-200'}`}
                  style={{ height: `${Math.max(height, 5)}%` }}
                  title={`${dateStr}: ${dayActivity?.count || 0} действий`}
                />
              )
            })}
          </div>
          <div className="flex justify-between mt-2 text-xs text-gray-400">
            <span>{new Date(Date.now() - 29 * 24 * 60 * 60 * 1000).toLocaleDateString('ru', { day: 'numeric', month: 'short' })}</span>
            <span>{new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toLocaleDateString('ru', { day: 'numeric', month: 'short' })}</span>
            <span>{new Date().toLocaleDateString('ru', { day: 'numeric', month: 'short' })}</span>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white border border-gray-200 rounded-xl p-6">
          <h2 className="font-medium text-gray-900 mb-6">Последняя активность</h2>
          <div className="space-y-4">
            {userStats?.recentActivity?.length ? userStats.recentActivity.map((activity, i) => (
              <div key={i} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
                <div>
                  <span className="text-gray-500">{activity.action}:</span>
                  <span className="text-gray-900 ml-2">{activity.item}</span>
                </div>
                <span className="text-sm text-gray-400">
                  {new Date(activity.time).toLocaleDateString('ru', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            )) : (
              <div className="text-center text-gray-400 py-4">Нет активности</div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

// Learn Discussions Page
export function LearnDiscussions() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [discussions, setDiscussions] = useState<Discussion[]>([])
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [createTitle, setCreateTitle] = useState('')
  const [createContent, setCreateContent] = useState('')
  const [createCourseId, setCreateCourseId] = useState<string>('')
  const [creating, setCreating] = useState(false)
  const [enrollments, setEnrollments] = useState<UserEnrollment[]>([])

  useEffect(() => {
    loadData()
    loadEnrollments()
  }, [])

  const loadEnrollments = async () => {
    try {
      const data = await userAPI.getEnrollments()
      setEnrollments(data || [])
    } catch (error) {
      console.error('Failed to load enrollments:', error)
    }
  }

  const loadData = async () => {
    try {
      const data = await userAPI.getDiscussions()
      setDiscussions(data || [])
    } catch (error) {
      console.error('Failed to load discussions:', error)
    }
    setLoading(false)
  }

  const handleCreate = async () => {
    if (!createTitle.trim() || !createContent.trim()) {
      alert('Заполните заголовок и содержание')
      return
    }

    setCreating(true)
    try {
      await userAPI.createDiscussion({
        title: createTitle.trim(),
        content: createContent.trim(),
        course_id: createCourseId || undefined
      })
      setShowCreateModal(false)
      setCreateTitle('')
      setCreateContent('')
      setCreateCourseId('')
      loadData()
    } catch (error: any) {
      alert(error.message || 'Ошибка создания обсуждения')
    } finally {
      setCreating(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex">
        <LearnSidebar active="discussions" />
        <main className="flex-1 p-8 flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full"></div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <LearnSidebar active="discussions" />
      <main className="flex-1 p-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-medium text-gray-900">Обсуждения</h1>
          <button 
            onClick={() => setShowCreateModal(true)}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600"
          >
            Новая тема
          </button>
        </div>
        
        {discussions.length === 0 ? (
          <div className="bg-white border border-gray-200 rounded-xl p-12 text-center">
            <MessageCircle className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-xl font-medium text-gray-400 mb-2">Пока нет обсуждений</h3>
            <p className="text-gray-400 mb-4">Создайте первую тему для обсуждения</p>
            <button 
              onClick={() => setShowCreateModal(true)}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600"
            >
              Создать тему
            </button>
          </div>
        ) : (
          <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
            {discussions.map((discussion, i) => (
              <div 
                key={discussion.id}
                onClick={() => navigate(`/learn/discussions/${discussion.id}`)}
                className={`p-6 hover:bg-gray-50 cursor-pointer ${i !== discussions.length - 1 ? 'border-b border-gray-100' : ''}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900 mb-1">{discussion.title}</h3>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span>{discussion.course || 'Общее'}</span>
                      <span>•</span>
                      <span>{discussion.author}</span>
                      <span>•</span>
                      <span>{discussion.time}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-500 ml-4">
                    <MessageCircle className="w-4 h-4" />
                    {discussion.replies}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Create Discussion Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowCreateModal(false)}>
            <div className="bg-white rounded-xl p-6 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
              <h2 className="text-xl font-medium text-gray-900 mb-4">Новая тема</h2>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">Заголовок</label>
                <input
                  type="text"
                  value={createTitle}
                  onChange={(e) => setCreateTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Введите заголовок темы"
                />
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">Курс (необязательно)</label>
                <select
                  value={createCourseId}
                  onChange={(e) => setCreateCourseId(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Общее обсуждение</option>
                  {enrollments.map(e => (
                    <option key={e.course.id} value={e.course.id}>{e.course.title}</option>
                  ))}
                </select>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">Содержание</label>
                <textarea
                  value={createContent}
                  onChange={(e) => setCreateContent(e.target.value)}
                  rows={8}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Опишите вашу тему..."
                />
              </div>

              <div className="flex gap-3 justify-end">
                <button
                  onClick={() => {
                    setShowCreateModal(false)
                    setCreateTitle('')
                    setCreateContent('')
                    setCreateCourseId('')
                  }}
                  className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Отмена
                </button>
                <button
                  onClick={handleCreate}
                  disabled={creating}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50"
                >
                  {creating ? 'Создание...' : 'Создать'}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}

// Discussion Detail Page
export function DiscussionDetail() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [discussion, setDiscussion] = useState<DiscussionDetail | null>(null)
  const [replyContent, setReplyContent] = useState('')
  const [replying, setReplying] = useState(false)

  useEffect(() => {
    if (id) {
      loadData()
    }
  }, [id])

  const loadData = async () => {
    if (!id) return
    try {
      const data = await userAPI.getDiscussion(id)
      setDiscussion(data)
    } catch (error) {
      console.error('Failed to load discussion:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleReply = async () => {
    if (!replyContent.trim() || !id) return

    setReplying(true)
    try {
      await userAPI.createReply(id, replyContent.trim())
      setReplyContent('')
      loadData() // Reload to get updated replies
    } catch (error: any) {
      alert(error.message || 'Ошибка отправки ответа')
    } finally {
      setReplying(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex">
        <LearnSidebar active="discussions" />
        <main className="flex-1 p-8 flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full"></div>
        </main>
      </div>
    )
  }

  if (!discussion) {
    return (
      <div className="min-h-screen bg-gray-50 flex">
        <LearnSidebar active="discussions" />
        <main className="flex-1 p-8">
          <div className="bg-white border border-gray-200 rounded-xl p-8 text-center">
            <h2 className="text-xl font-medium text-gray-900 mb-2">Обсуждение не найдено</h2>
            <button
              onClick={() => navigate('/learn/discussions')}
              className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
            >
              Вернуться к обсуждениям
            </button>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <LearnSidebar active="discussions" />
      <main className="flex-1 p-8">
        <button
          onClick={() => navigate('/learn/discussions')}
          className="mb-4 text-sm text-gray-600 hover:text-gray-900 flex items-center gap-1"
        >
          <ArrowRight className="w-4 h-4 rotate-180" />
          Назад к обсуждениям
        </button>

        <div className="bg-white border border-gray-200 rounded-xl p-6 mb-4">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h1 className="text-2xl font-medium text-gray-900 mb-2">{discussion.title}</h1>
              <div className="flex items-center gap-4 text-sm text-gray-500">
                <span>{discussion.course || 'Общее'}</span>
                <span>•</span>
                <span>{discussion.author}</span>
                <span>•</span>
                <span>{discussion.time}</span>
              </div>
            </div>
          </div>
          
          <div className="prose max-w-none text-gray-700 whitespace-pre-wrap mb-6">
            {discussion.content}
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-6 mb-4">
          <h2 className="text-lg font-medium text-gray-900 mb-4">
            Ответы ({discussion.replies_list?.length || 0})
          </h2>

          {discussion.replies_list && discussion.replies_list.length > 0 ? (
            <div className="space-y-4">
              {discussion.replies_list.map((reply) => (
                <div key={reply.id} className="border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                  <div className="flex items-start gap-3 mb-2">
                    <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center text-sm font-medium text-gray-600">
                      {reply.author.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-gray-900">{reply.author}</span>
                        <span className="text-sm text-gray-500">•</span>
                        <span className="text-sm text-gray-500">{reply.time}</span>
                      </div>
                      <div className="text-gray-700 whitespace-pre-wrap">{reply.content}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8">Пока нет ответов</p>
          )}
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Оставить ответ</h3>
          <textarea
            value={replyContent}
            onChange={(e) => setReplyContent(e.target.value)}
            rows={4}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
            placeholder="Напишите ваш ответ..."
          />
          <button
            onClick={handleReply}
            disabled={!replyContent.trim() || replying}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50"
          >
            {replying ? 'Отправка...' : 'Отправить'}
          </button>
        </div>
      </main>
    </div>
  )
}

// Quiz Page Component
function QuizPage({ lesson, navigation }: { lesson: any; navigation: any }) {
  const navigate = useNavigate()
  const [started, setStarted] = useState(false)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<number[]>([])
  const [showResults, setShowResults] = useState(false)

  // Load questions from lesson content
  const questions = (() => {
    if (!lesson?.content) return []
    try {
      const parsed = JSON.parse(lesson.content)
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((q: any, index: number) => ({
          id: q.id || index + 1,
          question: q.question || '',
          options: q.options || ['', '', '', ''],
          correct: q.correct ?? 0
        }))
      }
    } catch (e) {
      console.error('Failed to parse quiz questions:', e)
    }
    return []
  })()

  const handleAnswer = (optionIndex: number) => {
    const newAnswers = [...answers]
    newAnswers[currentQuestion] = optionIndex
    setAnswers(newAnswers)
  }

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      setShowResults(true)
    }
  }

  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const correctCount = answers.reduce((count, answer, index) => {
    return count + (answer === questions[index].correct ? 1 : 0)
  }, 0)

  const percentage = questions.length > 0 ? Math.round((correctCount / questions.length) * 100) : 0

  // If no questions, show message
  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-white flex">
        <main className="flex-1 flex items-center justify-center p-8">
          <div className="max-w-md text-center">
            <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <HelpCircle className="w-10 h-10 text-orange-500" />
            </div>
            <h1 className="text-2xl font-medium text-gray-900 mb-4">{lesson.title}</h1>
            <p className="text-gray-500 mb-8">Вопросы для теста еще не добавлены преподавателем</p>
            <Link to="/learn" className="text-sm text-gray-500 hover:text-gray-700">
              ← Вернуться к курсу
            </Link>
          </div>
        </main>
      </div>
    )
  }

  if (!started) {
    return (
      <div className="min-h-screen bg-white flex">
        <main className="flex-1 flex items-center justify-center p-8">
          <div className="max-w-md text-center">
            <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <HelpCircle className="w-10 h-10 text-orange-500" />
            </div>
            <h1 className="text-2xl font-medium text-gray-900 mb-4">{lesson.title}</h1>
            <p className="text-gray-500 mb-2">Проверьте свои знания по пройденному материалу</p>
            <p className="text-sm text-gray-400 mb-8">{questions.length} вопросов • ~5 минут</p>
            <button 
              onClick={() => setStarted(true)}
              className="px-8 py-3 bg-orange-500 text-white rounded-lg font-medium hover:bg-orange-600 transition-colors"
            >
              Начать тест
            </button>
            <div className="mt-4">
              <Link to="/learn" className="text-sm text-gray-500 hover:text-gray-700">
                ← Вернуться к курсу
              </Link>
            </div>
          </div>
        </main>
      </div>
    )
  }

  if (showResults) {
    const passed = percentage >= 70
    return (
      <div className="min-h-screen bg-white flex">
        <main className="flex-1 flex items-center justify-center p-8">
          <div className="max-w-md text-center">
            <div className={`w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 ${
              passed ? 'bg-green-100' : 'bg-red-100'
            }`}>
              <span className="text-4xl">{passed ? '🎉' : '😢'}</span>
            </div>
            <h1 className="text-2xl font-medium text-gray-900 mb-2">
              {passed ? 'Тест пройден!' : 'Тест не пройден'}
            </h1>
            <p className="text-gray-500 mb-4">
              Правильных ответов: {correctCount} из {questions.length} ({percentage}%)
            </p>
            
            <div className="w-full h-4 bg-gray-200 rounded-full mb-6">
              <div 
                className={`h-4 rounded-full transition-all ${passed ? 'bg-green-500' : 'bg-red-500'}`}
                style={{ width: `${percentage}%` }}
              />
            </div>

            <div className="space-y-2 text-left mb-6 max-h-60 overflow-y-auto">
              {questions.map((q, i) => (
                <div key={q.id} className={`p-3 rounded-lg ${answers[i] === q.correct ? 'bg-green-50' : 'bg-red-50'}`}>
                  <div className="flex items-start gap-2">
                    <span>{answers[i] === q.correct ? '✅' : '❌'}</span>
                    <div>
                      <p className="text-sm font-medium text-gray-900">{q.question}</p>
                      {answers[i] !== q.correct && (
                        <p className="text-xs text-gray-500 mt-1">
                          Правильный ответ: {q.options[q.correct]}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-3">
              {!passed && (
                <button 
                  onClick={() => { setStarted(false); setAnswers([]); setCurrentQuestion(0); setShowResults(false) }}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Попробовать снова
                </button>
              )}
              <button 
                onClick={() => navigation.next ? navigate(`/learn/lesson/${navigation.next.id}`) : navigate('/learn')}
                className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
              >
                {navigation.next ? 'Следующий урок' : 'К курсу'}
              </button>
            </div>
          </div>
        </main>
      </div>
    )
  }

  const question = questions[currentQuestion]

  return (
    <div className="min-h-screen bg-white flex">
      <main className="flex-1 p-8">
        <div className="max-w-2xl mx-auto">
          {/* Progress */}
          <div className="mb-8">
            <div className="flex items-center justify-between text-sm text-gray-500 mb-2">
              <span>Вопрос {currentQuestion + 1} из {questions.length}</span>
              <Link to="/learn" className="hover:text-gray-700">Выйти из теста</Link>
            </div>
            <div className="w-full h-2 bg-gray-200 rounded-full">
              <div 
                className="h-2 bg-orange-500 rounded-full transition-all"
                style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Question */}
          <div className="mb-8">
            <h2 className="text-xl font-medium text-gray-900 mb-6">{question.question}</h2>
            <div className="space-y-3">
              {question.options.map((option: string, i: number) => (
                <button
                  key={i}
                  onClick={() => handleAnswer(i)}
                  className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                    answers[currentQuestion] === i
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <span className="font-medium">{String.fromCharCode(65 + i)}.</span> {option}
                </button>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-between">
            <button 
              onClick={prevQuestion}
              disabled={currentQuestion === 0}
              className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50"
            >
              ← Назад
            </button>
            <button 
              onClick={nextQuestion}
              disabled={answers[currentQuestion] === undefined}
              className="px-6 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 disabled:opacity-50"
            >
              {currentQuestion === questions.length - 1 ? 'Завершить' : 'Далее →'}
            </button>
          </div>
        </div>
      </main>
    </div>
  )
}

// File Tree Types
interface FileNode {
  name: string
  type: 'file' | 'folder'
  children?: FileNode[]
  content?: string
  language?: string
}

// File Tree Component
function FileTree({ 
  files, 
  activeFile, 
  onFileSelect,
  expandedFolders,
  onToggleFolder,
  level = 0 
}: { 
  files: FileNode[]
  activeFile: string
  onFileSelect: (file: FileNode) => void
  expandedFolders: Set<string>
  onToggleFolder: (path: string) => void
  level?: number
}) {
  const getFileIcon = (file: FileNode) => {
    if (file.type === 'folder') {
      return expandedFolders.has(file.name) ? '📂' : '📁'
    }
    const ext = file.name.split('.').pop()?.toLowerCase()
    const name = file.name.toLowerCase()
    
    // Special files
    if (name === 'makefile') return '⚙️'
    if (name === 'dockerfile') return '🐳'
    if (name.startsWith('.git')) return '📦'
    
    switch (ext) {
      case 'java': return '☕'
      case 'js': case 'jsx': case 'mjs': return '🟨'
      case 'ts': case 'tsx': return '🔷'
      case 'py': case 'pyw': return '🐍'
      case 'cpp': case 'cc': case 'cxx': case 'c': case 'h': case 'hpp': return '⚡'
      case 'go': return '🔵'
      case 'rs': return '🦀'
      case 'kt': case 'kts': return '💜'
      case 'cs': return '💚'
      case 'rb': return '💎'
      case 'php': return '🐘'
      case 'swift': return '🧡'
      case 'scala': return '🔴'
      case 'md': case 'markdown': return '📝'
      case 'json': return '📋'
      case 'xml': return '📄'
      case 'html': case 'htm': return '🌐'
      case 'css': case 'scss': case 'sass': case 'less': return '🎨'
      case 'yaml': case 'yml': return '⚙️'
      case 'toml': return '📦'
      case 'sql': return '🗄️'
      case 'sh': case 'bash': case 'zsh': return '💻'
      case 'txt': return '📃'
      case 'log': return '📜'
      default: return '📄'
    }
  }

  return (
    <div>
      {files.map((file) => (
        <div key={file.name}>
          <div
            onClick={() => {
              if (file.type === 'folder') {
                onToggleFolder(file.name)
              } else {
                onFileSelect(file)
              }
            }}
            className={`flex items-center gap-2 px-2 py-1 cursor-pointer text-sm transition-colors ${
              activeFile === file.name 
                ? 'bg-[#37373d] text-white' 
                : 'text-gray-400 hover:bg-[#2a2d2e] hover:text-gray-200'
            }`}
            style={{ paddingLeft: `${level * 12 + 8}px` }}
          >
            {file.type === 'folder' && (
              <span className="text-[10px] text-gray-500">
                {expandedFolders.has(file.name) ? '▼' : '▶'}
              </span>
            )}
            <span>{getFileIcon(file)}</span>
            <span className="truncate">{file.name}</span>
          </div>
          {file.type === 'folder' && file.children && expandedFolders.has(file.name) && (
            <FileTree 
              files={file.children} 
              activeFile={activeFile}
              onFileSelect={onFileSelect}
              expandedFolders={expandedFolders}
              onToggleFolder={onToggleFolder}
              level={level + 1}
            />
          )}
        </div>
      ))}
    </div>
  )
}

// Exercise Page with Code Editor
function ExercisePage({ lessonData }: { lessonData?: any } = {}) {
  const [testResults, setTestResults] = useState<{ passed: number; total: number; results: any[] } | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  // Get exercise data from lessonData prop
  const exercise = lessonData?.exercise
  const lesson = lessonData?.lesson
  const exerciseTitle = exercise?.title || lesson?.title || 'Практика'
  const exerciseDescription = exercise?.description || ''
  const exerciseHints = exercise?.hints || ['Используйте оператор + для сложения двух чисел', 'Не забудьте return']
  const testCases = exercise?.test_cases || []

  const defaultReadme = `# ${exerciseTitle}

${exerciseDescription || 'Реализуйте функцию согласно заданию.'}

## Примеры

${testCases.filter((t: any) => !t.is_hidden).map((tc: any, i: number) => 
  `**Тест ${i + 1}:**\n- Вход: \`${tc.input || '(нет входа)'}\`\n- Ожидаемый выход: \`${tc.expected || tc.expected_output || '(не указано)'}\``
).join('\n\n') || 'Примеры будут отображаться здесь.'}

## Подсказки

${exerciseHints.map((h: string, i: number) => `${i + 1}. ${h}`).join('\n')}
`

  // Get initial code from exercise or use default
  const exerciseInitialCode = exercise?.initial_code || ''
  const exerciseLanguage = exercise?.language || 'java'

  // Generate initial code for different languages based on exercise
  const getInitialCode = (lang: string) => {
    // If exercise has initial_code, use it for the matching language
    if (exerciseInitialCode && exerciseLanguage === lang) {
      return exerciseInitialCode
    }
    // Default templates for other languages
    const defaults: Record<string, string> = {
      java: `public class Solution {
    public static void main(String[] args) {
        // Ваш код здесь
    }
}`,
      python: `# Ваш код здесь
`,
      javascript: `// Ваш код здесь
`,
      typescript: `// Ваш код здесь
`,
      cpp: `#include <iostream>
using namespace std;

int main() {
    // Ваш код здесь
    return 0;
}`,
      go: `package main

import "fmt"

func main() {
    // Ваш код здесь
}`,
      rust: `fn main() {
    // Ваш код здесь
}`,
      kotlin: `fun main() {
    // Ваш код здесь
}`,
      csharp: `using System;

class Solution {
    static void Main(string[] args) {
        // Ваш код здесь
    }
}`
    }
    return defaults[lang] || '// Ваш код здесь'
  }

  // Language-specific file configurations
  const languageConfig: Record<string, { mainFile: string; testFile: string; icon: string }> = {
    java: { mainFile: 'Solution.java', testFile: 'SolutionTest.java', icon: '☕' },
    python: { mainFile: 'solution.py', testFile: 'test_solution.py', icon: '🐍' },
    javascript: { mainFile: 'solution.js', testFile: 'solution.test.js', icon: '🟨' },
    typescript: { mainFile: 'solution.ts', testFile: 'solution.test.ts', icon: '🔷' },
    cpp: { mainFile: 'solution.cpp', testFile: 'test_solution.cpp', icon: '⚡' },
    go: { mainFile: 'solution.go', testFile: 'solution_test.go', icon: '🔵' },
    rust: { mainFile: 'solution.rs', testFile: 'solution_test.rs', icon: '🦀' },
    kotlin: { mainFile: 'Solution.kt', testFile: 'SolutionTest.kt', icon: '💜' },
    csharp: { mainFile: 'Solution.cs', testFile: 'SolutionTest.cs', icon: '💚' },
  }

  const currentLangConfig = languageConfig[exerciseLanguage] || languageConfig.java

  // File contents - dynamic based on exercise language
  const initialFileContents: Record<string, string> = {
    [currentLangConfig.mainFile]: getInitialCode(exerciseLanguage),
    'README.md': defaultReadme,
  }

  // Generate file contents with auto-detected languages
  const generateFileContents = () => {
    const contents: Record<string, { content: string; language: string }> = {}
    for (const [filename, content] of Object.entries(initialFileContents)) {
      contents[filename] = {
        content,
        language: getLanguageFromFilename(filename)
      }
    }
    return contents
  }

  // Project structure - dynamic based on exercise language
  const projectFiles: FileNode[] = [
    {
      name: 'src',
      type: 'folder',
      children: [
        { name: currentLangConfig.mainFile, type: 'file' },
      ]
    },
    { name: 'README.md', type: 'file' },
  ]

  const [activeFile, setActiveFile] = useState(currentLangConfig.mainFile)
  const [openTabs, setOpenTabs] = useState<string[]>([currentLangConfig.mainFile])
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['src']))
  const [files, setFiles] = useState(() => generateFileContents())

  // Update files when exercise language changes
  useEffect(() => {
    setActiveFile(currentLangConfig.mainFile)
    setOpenTabs([currentLangConfig.mainFile])
    setFiles(generateFileContents())
  }, [exerciseLanguage])
  const [output, setOutput] = useState('')
  const [isRunning, setIsRunning] = useState(false)
  const [activeTab, setActiveTab] = useState<'editor' | 'output' | 'readme'>('editor')
  const [activeBottomTab, setActiveBottomTab] = useState('terminal')
  const [terminalOutput, setTerminalOutput] = useState('$ ')

  const currentFile = files[activeFile]

  const handleFileSelect = (file: FileNode) => {
    if (file.type === 'file') {
      setActiveFile(file.name)
      if (!openTabs.includes(file.name)) {
        setOpenTabs([...openTabs, file.name])
      }
      setActiveTab('editor')
    }
  }

  const handleToggleFolder = (folderName: string) => {
    const newExpanded = new Set(expandedFolders)
    if (newExpanded.has(folderName)) {
      newExpanded.delete(folderName)
    } else {
      newExpanded.add(folderName)
    }
    setExpandedFolders(newExpanded)
  }

  const handleCloseTab = (fileName: string) => {
    const newTabs = openTabs.filter(t => t !== fileName)
    setOpenTabs(newTabs)
    if (activeFile === fileName && newTabs.length > 0) {
      setActiveFile(newTabs[newTabs.length - 1])
    }
  }

  const handleCodeChange = (value: string | undefined) => {
    if (value !== undefined) {
      setFiles(prev => ({
        ...prev,
        [activeFile]: { ...prev[activeFile], content: value }
      }))
    }
  }

  const [serverOnline, setServerOnline] = useState<boolean | null>(null)
  const [problems, setProblems] = useState<{line: number; message: string; severity: string}[]>([])

  // Check server status on mount
  useEffect(() => {
    healthCheck().then(setServerOnline)
  }, [])

  // Lint code on change
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (currentFile && serverOnline) {
        const lang = getLanguageFromExtension(activeFile)
        const result = await lintCode(currentFile.content, lang)
        setProblems([...result.errors, ...result.warnings])
      }
    }, 500)
    return () => clearTimeout(timer)
  }, [currentFile?.content, activeFile, serverOnline])

  const runCode = async () => {
    setIsRunning(true)
    setActiveTab('output')
    setOutput('⏳ Подготовка к выполнению...\n')
    setTestResults(null)
    
    const lang = getLanguageFromExtension(activeFile)
    const code = currentFile?.content || ''
    
    setTerminalOutput(`$ Running ${activeFile}...\n`)
    setOutput(`⏳ Компиляция ${activeFile}...\n`)

    try {
      // Run with test cases if available
      const result = await executeCode(code, lang, '', testCases)
      
      if (result.success) {
        // Check if we have test results
        if (result.testResults && result.testResults.length > 0) {
          const passed = result.testResults.filter((t: any) => t.passed).length
          const total = result.testResults.length
          const allPassed = passed === total

          setTestResults({ passed, total, results: result.testResults })
          
          let outputText = allPassed 
            ? `✅ Все тесты пройдены! (${passed}/${total})\n\n`
            : `❌ Тесты не пройдены (${passed}/${total})\n\n`
          
          outputText += `━━━━━━━━━━ Результаты тестов ━━━━━━━━━━\n\n`
          
          result.testResults.forEach((test: any, i: number) => {
            const status = test.passed ? '✅' : '❌'
            const hidden = test.isHidden ? ' (скрытый)' : ''
            outputText += `${status} Тест ${i + 1}${hidden}\n`
            if (!test.isHidden) {
              outputText += `   Вход: ${test.input || '(пусто)'}\n`
              outputText += `   Ожидалось: ${test.expected}\n`
              outputText += `   Получено: ${test.actual}\n`
            }
            outputText += '\n'
          })

          outputText += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`
          if (result.executionTime) {
            outputText += `⏱️ Время выполнения: ${result.executionTime}ms\n\n`
          }
          
          if (allPassed) {
            outputText += `🎉 Отличная работа! Теперь вы можете отправить решение преподавателю.`
          } else {
            outputText += `💡 Проверьте логику вашего решения и попробуйте снова.`
          }

          setOutput(outputText)
        } else {
          // No test cases, just show output
          setOutput(
            `✅ Компиляция успешна!\n\n` +
            `━━━━━━━━━━ Output ━━━━━━━━━━\n\n` +
            `${result.output || '(нет вывода)'}\n\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
            `⏱️ Время выполнения: ${result.executionTime}ms`
          )
        }
        setTerminalOutput(prev => prev + (result.output || '') + '\n$ ')
      } else {
        if (result.stage === 'compile') {
          setOutput(
            `❌ Ошибка компиляции!\n\n` +
            `━━━━━━━━━━ Errors ━━━━━━━━━━\n\n` +
            `${result.error}\n\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
            (result.errors?.map((e: any) => `Line ${e.line}: ${e.message}`).join('\n') || '')
          )
          if (result.errors) {
            setProblems(result.errors.map((e: any) => ({
              line: e.line || 1,
              message: e.message,
              severity: 'error'
            })))
          }
        } else if (result.timedOut) {
          setOutput(
            `⏰ Превышено время выполнения!\n\n` +
            `Программа выполнялась слишком долго и была остановлена.\n` +
            `Проверьте наличие бесконечных циклов.`
          )
        } else {
          setOutput(
            `❌ Ошибка выполнения!\n\n` +
            `━━━━━━━━━━ Error ━━━━━━━━━━\n\n` +
            `${result.error}\n\n` +
            (result.output ? `━━━━━━━━━━ Output ━━━━━━━━━━\n\n${result.output}` : '')
          )
        }
        setTerminalOutput(prev => prev + `Error: ${result.error}\n$ `)
      }
    } catch (error) {
      setOutput(
        `🔌 Сервер недоступен!\n\n` +
        `Убедитесь, что бэкенд запущен:\n\n` +
        `  cd server\n` +
        `  npm install\n` +
        `  npm start\n\n` +
        `Сервер должен работать на http://localhost:3001`
      )
    }
    
    setIsRunning(false)
  }

  // Submit solution to teacher
  const submitSolution = async () => {
    if (!exercise || !lessonData) {
      alert('Упражнение не загружено')
      return
    }

    setIsSubmitting(true)
    try {
      const token = localStorage.getItem('token')
      const response = await fetch('http://localhost:3001/api/submissions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          exercise_id: exercise.id,
          code: currentFile?.content || '',
          language: getLanguageFromExtension(activeFile),
          test_results: testResults
        })
      })

      if (response.ok) {
        setSubmitted(true)
        alert('✅ Решение отправлено преподавателю на проверку!')
      } else {
        const err = await response.json()
        alert(`❌ Ошибка: ${err.error}`)
      }
    } catch (error) {
      alert('❌ Не удалось отправить решение')
    }
    setIsSubmitting(false)
  }

  const resetCode = () => {
    setFiles(prev => ({
      ...prev,
      [currentLangConfig.mainFile]: { 
        ...prev[currentLangConfig.mainFile], 
        content: initialFileContents[currentLangConfig.mainFile] 
      }
    }))
    setOutput('')
    setTerminalOutput('$ ')
  }

  const [hintIndex, setHintIndex] = useState(0)
  
  const showHint = () => {
    if (exerciseHints.length > 0) {
      alert(`💡 Подсказка ${hintIndex + 1}/${exerciseHints.length}:\n\n${exerciseHints[hintIndex]}`)
      setHintIndex((hintIndex + 1) % exerciseHints.length)
    } else {
      alert('💡 Подсказка: Используйте оператор + для сложения двух чисел.\n\nПример: return a + b;')
    }
  }

  return (
    <div className="h-screen flex flex-col bg-[#1e1e1e]">
      {/* Top Bar */}
      <div className="h-10 bg-[#252526] border-b border-[#3c3c3c] flex items-center justify-between px-4">
        <div className="flex items-center gap-4">
          <Link to="/learn" className="text-gray-400 hover:text-white text-sm flex items-center gap-1">
            <span>←</span> Назад к курсу
          </Link>
          <span className="text-gray-600">|</span>
          <span className="text-gray-300 text-sm font-medium">{exerciseTitle}</span>
        </div>
        <div className="flex items-center gap-3 text-sm">
          <span className="text-gray-500">java-practice</span>
          <span className="px-2 py-0.5 bg-green-600 text-white text-xs rounded">
            {getLanguageFromExtension(activeFile).toUpperCase()}
          </span>
          <span className={`px-2 py-0.5 text-white text-xs rounded flex items-center gap-1 ${
            serverOnline === null ? 'bg-gray-600' : serverOnline ? 'bg-green-600' : 'bg-red-600'
          }`}>
            <span className={`w-2 h-2 rounded-full ${
              serverOnline === null ? 'bg-gray-400' : serverOnline ? 'bg-green-300 animate-pulse' : 'bg-red-400'
            }`}></span>
            {serverOnline === null ? 'Connecting...' : serverOnline ? 'Server Online' : 'Server Offline'}
          </span>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* File Tree / Project Explorer */}
        <div className="w-[240px] bg-[#252526] border-r border-[#3c3c3c] flex flex-col">
          {/* Explorer Header */}
          <div className="px-4 py-2 text-[11px] text-gray-400 uppercase tracking-wider font-semibold border-b border-[#3c3c3c] flex items-center justify-between">
            <span>Explorer</span>
            <div className="flex items-center gap-1">
              <button className="p-1 hover:bg-[#3c3c3c] rounded" title="New File">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </button>
              <button className="p-1 hover:bg-[#3c3c3c] rounded" title="New Folder">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
                </svg>
              </button>
              <button className="p-1 hover:bg-[#3c3c3c] rounded" title="Refresh">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
              </button>
            </div>
          </div>
          
          {/* Project Name */}
          <div className="px-2 py-2 text-[11px] text-gray-300 font-medium border-b border-[#3c3c3c] flex items-center gap-2">
            <span className="text-yellow-500">▼</span>
            <span>JAVA-PRACTICE</span>
          </div>
          
          {/* File Tree */}
          <div className="flex-1 overflow-y-auto py-1">
            <FileTree 
              files={projectFiles}
              activeFile={activeFile}
              onFileSelect={handleFileSelect}
              expandedFolders={expandedFolders}
              onToggleFolder={handleToggleFolder}
            />
          </div>

          {/* Outline Section */}
          <div className="border-t border-[#3c3c3c]">
            <div className="px-4 py-2 text-[11px] text-gray-400 uppercase tracking-wider font-semibold flex items-center gap-2">
              <span className="text-gray-500">▶</span>
              <span>Outline</span>
            </div>
          </div>
        </div>

        {/* Editor Area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Open File Tabs */}
          <div className="h-9 bg-[#252526] flex items-center border-b border-[#3c3c3c] overflow-x-auto">
            {openTabs.map((tab) => {
              const getTabIcon = (name: string) => {
                const ext = name.split('.').pop()?.toLowerCase()
                const fileName = name.toLowerCase()
                if (fileName === 'makefile') return '⚙️'
                if (fileName.startsWith('.git')) return '📦'
                switch (ext) {
                  case 'java': return '☕'
                  case 'js': case 'jsx': return '🟨'
                  case 'ts': case 'tsx': return '🔷'
                  case 'py': return '🐍'
                  case 'cpp': case 'c': case 'h': return '⚡'
                  case 'go': return '🔵'
                  case 'rs': return '🦀'
                  case 'kt': return '💜'
                  case 'cs': return '💚'
                  case 'md': return '📝'
                  case 'json': return '📋'
                  case 'xml': return '📄'
                  case 'yaml': case 'yml': return '⚙️'
                  case 'toml': return '📦'
                  default: return '📄'
                }
              }
              return (
                <div 
                  key={tab}
                  onClick={() => { setActiveFile(tab); setActiveTab('editor') }}
                  className={`group px-3 h-full text-sm flex items-center gap-2 border-r border-[#3c3c3c] cursor-pointer ${
                    activeFile === tab && activeTab === 'editor'
                      ? 'bg-[#1e1e1e] text-white' 
                      : 'text-gray-400 hover:text-gray-200'
                  }`}
                >
                  <span>{getTabIcon(tab)}</span>
                  <span>{tab}</span>
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleCloseTab(tab) }}
                    className="ml-1 p-0.5 rounded hover:bg-[#3c3c3c] opacity-0 group-hover:opacity-100"
                  >
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              )
            })}
            <button 
              onClick={() => setActiveTab('output')}
              className={`px-3 h-full text-sm flex items-center gap-2 border-r border-[#3c3c3c] ${
                activeTab === 'output' ? 'bg-[#1e1e1e] text-white' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              📤 Output
            </button>
          </div>

          {/* Editor Content */}
          <div className="flex-1 overflow-hidden">
            {activeTab === 'output' ? (
              <div className="h-full p-4 font-mono text-sm bg-[#1e1e1e] overflow-y-auto whitespace-pre-wrap">
                {output ? (
                  <div className={output.includes('✅') || output.includes('🎉') ? 'text-green-400' : output.includes('❌') ? 'text-red-400' : 'text-gray-300'}>
                    {output}
                  </div>
                ) : (
                  <div className="text-gray-500">
                    <p className="mb-4">Нажмите "Проверить" для запуска кода</p>
                    <div className="text-gray-600 text-xs">
                      <p>Горячие клавиши:</p>
                      <p className="mt-1">• Ctrl+Enter — Запустить код</p>
                      <p>• Ctrl+S — Сохранить</p>
                    </div>
                  </div>
                )}
              </div>
            ) : currentFile ? (
              <Editor
                height="100%"
                language={currentFile.language}
                theme="vs-dark"
                value={currentFile.content}
                onChange={handleCodeChange}
                options={{
                  fontSize: 14,
                  fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', Consolas, monospace",
                  minimap: { enabled: true, scale: 0.8 },
                  scrollBeyondLastLine: false,
                  automaticLayout: true,
                  tabSize: 4,
                  wordWrap: 'on',
                  lineNumbers: 'on',
                  glyphMargin: true,
                  folding: true,
                  lineDecorationsWidth: 10,
                  lineNumbersMinChars: 3,
                  renderLineHighlight: 'all',
                  cursorBlinking: 'smooth',
                  cursorSmoothCaretAnimation: 'on',
                  smoothScrolling: true,
                  padding: { top: 10, bottom: 10 },
                  bracketPairColorization: { enabled: true },
                  guides: {
                    bracketPairs: true,
                    indentation: true,
                  },
                  suggest: {
                    showKeywords: true,
                    showSnippets: true,
                  },
                }}
              />
            ) : (
              <div className="h-full flex items-center justify-center text-gray-500">
                Выберите файл для редактирования
              </div>
            )}
          </div>

          {/* Bottom Panel */}
          <div className="h-[180px] bg-[#1e1e1e] border-t border-[#3c3c3c]">
            <div className="h-8 bg-[#252526] flex items-center text-sm border-b border-[#3c3c3c]">
              {['Problems', 'Terminal', 'Debug Console'].map((tab) => (
                <button 
                  key={tab}
                  onClick={() => setActiveBottomTab(tab.toLowerCase().replace(' ', ''))}
                  className={`px-4 h-full ${activeBottomTab === tab.toLowerCase().replace(' ', '') ? 'text-white bg-[#1e1e1e]' : 'text-gray-400 hover:text-gray-200'}`}
                >
                  {tab}
                </button>
              ))}
            </div>
            <div className="p-3 font-mono text-sm text-gray-400 h-[140px] overflow-y-auto">
              {activeBottomTab === 'terminal' ? (
                <div>
                  <div className="mb-2">
                    <span className="text-green-400">user@hexlet</span>
                    <span className="text-white">:</span>
                    <span className="text-blue-400">~/project</span>
                    <span className="text-white">$ </span>
                    <span className="text-gray-300">{terminalOutput || 'Ready'}</span>
                  </div>
                </div>
              ) : activeBottomTab === 'problems' ? (
                <div>
                  {problems.length === 0 ? (
                    <div className="text-green-500 flex items-center gap-2">
                      <span>✓</span> No problems detected
                    </div>
                  ) : (
                    <div className="space-y-1">
                      {problems.map((p, i) => (
                        <div 
                          key={i}
                          className={`flex items-start gap-2 ${
                            p.severity === 'error' ? 'text-red-400' : 'text-yellow-400'
                          }`}
                        >
                          <span>{p.severity === 'error' ? '❌' : '⚠️'}</span>
                          <span className="text-gray-500">Line {p.line}:</span>
                          <span>{p.message}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-gray-500">Debug console is empty</div>
              )}
            </div>
          </div>
        </div>

        {/* Right Sidebar */}
        <aside className="w-[260px] bg-white border-l border-gray-200 flex flex-col">
          {/* Action buttons */}
          <div className="flex flex-col">
            <button 
              onClick={runCode}
              disabled={isRunning}
              className={`flex items-center justify-center gap-2 px-6 py-4 text-white font-medium transition-colors ${
                isRunning ? 'bg-gray-400' : 'bg-green-500 hover:bg-green-600'
              }`}
            >
              {isRunning ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Выполняется...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" /> Проверить
                </>
              )}
            </button>
            
            {/* Submit button - only show if tests passed */}
            {testResults && testResults.passed === testResults.total && !submitted && (
              <button 
                onClick={submitSolution}
                disabled={isSubmitting}
                className="flex items-center justify-center gap-2 px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white font-medium transition-colors"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Отправка...
                  </>
                ) : (
                  <>
                    <ArrowRight className="w-4 h-4" /> Отправить преподавателю
                  </>
                )}
              </button>
            )}
            
            {submitted && (
              <div className="px-4 py-3 bg-green-100 text-green-700 text-sm text-center">
                ✅ Решение отправлено!
              </div>
            )}
          </div>

          {/* Test Results Summary */}
          {testResults && (
            <div className={`p-3 text-sm ${testResults.passed === testResults.total ? 'bg-green-50' : 'bg-red-50'}`}>
              <div className="flex items-center gap-2 font-medium">
                {testResults.passed === testResults.total ? (
                  <><CheckCircle className="w-4 h-4 text-green-600" /> Все тесты пройдены!</>
                ) : (
                  <><span className="text-red-600">❌</span> {testResults.passed}/{testResults.total} тестов</>
                )}
              </div>
            </div>
          )}

          <div className="p-4 flex-1 overflow-y-auto">
            {/* Task description */}
            <div className="mb-4 p-3 bg-blue-50 rounded-lg">
              <h3 className="text-sm font-medium text-blue-900 mb-1">📋 {exerciseTitle}</h3>
              {exerciseDescription && (
                <p className="text-xs text-blue-700 line-clamp-3">{exerciseDescription.slice(0, 150)}...</p>
              )}
              <button 
                onClick={() => setActiveTab('readme')}
                className="text-xs text-blue-600 hover:underline mt-2"
              >
                Читать полностью →
              </button>
            </div>

            <Link to="/learn" className="flex items-center gap-3 w-full px-3 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg">
              <Home className="w-5 h-5" />
              Назад к курсу
            </Link>
            
            <div className="mt-4 px-3">
              <div className="text-sm text-gray-500">
                {lessonData?.navigation 
                  ? `Урок ${lessonData.navigation.current} из ${lessonData.navigation.total}`
                  : 'пройдено 20 уроков из 45'
                }
              </div>
              <div className="h-2 bg-gray-200 rounded-full mt-2">
                <div 
                  className="h-2 bg-green-500 rounded-full transition-all" 
                  style={{ width: lessonData?.navigation ? `${(lessonData.navigation.current / lessonData.navigation.total) * 100}%` : '44%' }} 
                />
              </div>
            </div>

            <div className="mt-6 space-y-1">
              <div className="px-3 py-2 text-sm font-medium text-gray-900">Шаг: упражнение</div>
              <button className="w-full text-left px-3 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg">💬 Обсуждение</button>
              <button className="w-full text-left px-3 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg">📚 Теория</button>
              <button className="w-full text-left px-3 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg">
                🤖 AI помощник
              </button>
            </div>

            <div className="mt-6 space-y-1 border-t border-gray-200 pt-4">
              <button 
                onClick={() => setActiveTab('readme')}
                className="w-full text-left px-3 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg"
              >
                📋 Полное задание
              </button>
              <button 
                onClick={resetCode}
                className="w-full text-left px-3 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg"
              >
                ↩️ Сброс кода
              </button>
              <button 
                onClick={showHint}
                className="w-full text-left px-3 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg"
              >
                💡 Подсказка ({exerciseHints.length})
              </button>
            </div>
          </div>

          {/* Bottom character */}
          <div className="p-4 text-center border-t border-gray-100">
            <div className="text-3xl">🦉</div>
            <p className="text-xs text-gray-400 mt-1">Hexlet Helper</p>
          </div>
        </aside>
      </div>
    </div>
  )
}


