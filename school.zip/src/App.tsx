import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { AuthProvider } from './contexts/AuthContext'
import { Header } from './components/Header'
import { Footer } from './components/Footer'
import { HomePage } from './pages/HomePage'
import { LoginPage } from './pages/LoginPage'
import { RegisterPage } from './pages/RegisterPage'
import { CourseCatalogPage } from './pages/CourseCatalogPage'
import { CoursePage } from './pages/CoursePage'
import { 
  DashboardPage, 
  DashboardHome, 
  DashboardCourses, 
  DashboardChallenges,
  DashboardSolutions,
  DashboardRating,
  DashboardContact,
  DashboardFeedback,
  DashboardTeams,
  DashboardChat,
  DashboardChatRoom
} from './pages/DashboardPage'
import { LearnRoadmap, LessonPage, LearnCourses, LearnProgress, LearnDiscussions, DiscussionDetail } from './pages/LearnPage'
import AdminPage from './pages/AdminPage'
import TeacherPage from './pages/TeacherPage'
import CourseStructureEditorPage from './pages/CourseEditorPage'

// Layout with Header and Footer
function MainLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Header />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  )
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Learning pages (no header/footer) */}
          <Route path="/learn" element={<LearnRoadmap />} />
          <Route path="/learn/courses" element={<LearnCourses />} />
          <Route path="/learn/progress" element={<LearnProgress />} />
          <Route path="/learn/discussions" element={<LearnDiscussions />} />
          <Route path="/learn/discussions/:id" element={<DiscussionDetail />} />
          <Route path="/learn/lesson/:lessonId" element={<LessonPage />} />
          
          {/* Admin Panel (no header/footer) */}
          <Route path="/admin/*" element={<AdminPage />} />
          
          {/* Teacher Panel (no header/footer) */}
          <Route path="/teacher/*" element={<TeacherPage />} />
          <Route path="/teacher/courses/:courseId/structure" element={<CourseStructureEditorPage />} />
          
          {/* Main pages with header/footer */}
          <Route path="/" element={<MainLayout><HomePage /></MainLayout>} />
          <Route path="/login" element={<MainLayout><LoginPage /></MainLayout>} />
          <Route path="/register" element={<MainLayout><RegisterPage /></MainLayout>} />
          <Route path="/courses" element={<MainLayout><CourseCatalogPage /></MainLayout>} />
          <Route path="/courses/:slug" element={<MainLayout><CoursePage /></MainLayout>} />
          
          {/* Dashboard Routes */}
          <Route path="/dashboard" element={<MainLayout><DashboardPage /></MainLayout>}>
            <Route index element={<DashboardHome />} />
            <Route path="courses" element={<DashboardCourses />} />
            <Route path="challenges" element={<DashboardChallenges />} />
            <Route path="solutions" element={<DashboardSolutions />} />
            <Route path="rating" element={<DashboardRating />} />
            <Route path="contact" element={<DashboardContact />} />
            <Route path="feedback" element={<DashboardFeedback />} />
            <Route path="teams" element={<DashboardTeams />} />
            <Route path="chat" element={<DashboardChat />} />
            <Route path="chat/:chatId" element={<DashboardChatRoom />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  )
}

export default App
